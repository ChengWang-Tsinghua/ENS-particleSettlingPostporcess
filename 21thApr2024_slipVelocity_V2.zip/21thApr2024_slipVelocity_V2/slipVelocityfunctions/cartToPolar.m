function [polar1, polar2, polar3] = cartToPolar(X1, X2, coordinate_system)
% CARTTOPOLAR converts Cartesian coordinates to cylindrical or spherical coordinates.
%   [r, theta, psi] = CARTTOPOLAR(X1, X2, coordinate_system) calculates either
%   cylindrical or spherical coordinates based on input positions X1 and X2
%   and the desired coordinate system.
%
%   Input:
%       X1                - Starting position in Cartesian coordinates.
%       X2                - Ending position in Cartesian coordinates.
%       coordinate_system - String specifying the desired coordinate system: 'cylindrical' or 'spherical'.
%
%   Output:
%       r     - Radial distance in cylindrical or spherical coordinates.
%       theta - Inclination angle (polar angle) in spherical coordinates.
%       phi   - Azimuthal angle in cylindrical or polar coordinates.
%

    % Calculate the difference in position vectors
    delta_r = X2 - X1;

    % Calculate cylindrical or spherical coordinates based on the specified coordinate system
    if strcmpi(coordinate_system, 'cylindrical')
        r = sqrt(delta_r(1)^2 + delta_r(2)^2);
        theta = atan2(delta_r(2), delta_r(1));
        z = delta_r(3);  % z-axis remains the same
        polar1 = r;
        polar2 = theta;
        polar3 = z;
    elseif strcmpi(coordinate_system, 'spherical')
        % see sketch here https://math.libretexts.org/Courses/Mount_Royal_University/MATH_2200%3A_Calculus_for_Scientists_II/7%3A_Vector_Spaces/5.7%3A_Cylindrical_and_Spherical_Coordinates
        r = sqrt(delta_r(1)^2 + delta_r(2)^2 + delta_r(3)^2);
        theta = atan2(delta_r(2), delta_r(1));% Azimuthal angle, range [0,2*pi]
        phi = acos(delta_r(3)/r); % Polar angle, range [0,pi]
        
        % Modify theta to be within [0, 2*pi]
        if theta < 0
            theta = theta + 2*pi;
        end
        polar1 = r;
        polar2 = theta;
        polar3 = phi;
    else
        error('Invalid coordinate system. Please specify either ''cylindrical'' or ''spherical''.');
    end
end
