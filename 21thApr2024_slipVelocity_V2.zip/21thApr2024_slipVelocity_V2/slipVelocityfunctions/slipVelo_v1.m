function slipVeloSpherical = slipVelo_v1(particle_part, tracers_part, neighborIdxAll, startTime, endTime, figEuler)

    Nframemax = 1e6;

    % Set default value for frame-related parameter
    nk = 1;
    % if nargin > 5
    %     nk = kexp;
    % end

    % Calculate start and end times within the frame limit
    tstart = mod(startTime(nk), Nframemax);
    tend = mod(endTime(nk), Nframemax);

    % Initialize structure to store slip velocity information
    slipVeloSpherical = struct('rho',[], 'theta',[], 'urel',[]);

    % Prepare indices for searching
    idx_front_back = sort(vertcat(neighborIdxAll(tstart:tend).idx));

    
    % load mean Fields
    if ~isempty(figEuler)
        load([figEuler,'averMeanInterpolant.mat'],'averMeanFV');
    end

    % Iterate over indices
    for i = 1:numel(idx_front_back)
        idxp = particle_part.Tf == tracers_part.Tf(idx_front_back(i));
        idxt = idx_front_back(i);

        % Extract position and velocity information for particles and tracers
        % 'Y' component is the gravity direction
        Xp = [particle_part.Xf(idxp), particle_part.Yf(idxp), particle_part.Zf(idxp)];
        Xf = [tracers_part.Xf(idxt), tracers_part.Yf(idxt), tracers_part.Zf(idxt)];

        Vp = [particle_part.Vx(idxp), particle_part.Vy(idxp), particle_part.Vz(idxp)];
        Vf = [tracers_part.Vx(idxt), tracers_part.Vy(idxt), tracers_part.Vz(idxt)];
        
        if ~isempty(figEuler)  
            Vf_local_mean(1) = averMeanFV.x(Xf(1),Xf(2),Xf(3));
            Vf_local_mean(2) = averMeanFV.y(Xf(1),Xf(2),Xf(3));
            Vf_local_mean(3) = averMeanFV.z(Xf(1),Xf(2),Xf(3));
    
            Vp_local_mean(1) = averMeanFV.x(Xp(1),Xp(2),Xp(3));
            Vp_local_mean(2) = averMeanFV.y(Xp(1),Xp(2),Xp(3));
            Vp_local_mean(3) = averMeanFV.z(Xp(1),Xp(2),Xp(3));
        else
            Vf_local_mean = [0,0,0];
            Vp_local_mean = [0,0,0];
        end

        Vf_subs = Vf - Vf_local_mean;
        Vp_subs = Vp - Vp_local_mean;
        slipVeloSpherical(i).urel = Vf_subs - Vp_subs; 
        slipVeloSpherical(i).urel_projectVp = dot((Vf_subs - Vp_subs),Vp_subs)/norm(Vp_subs); 
        
        deltax = Xf(1) - Xp(1);
        deltay = Xf(2) - Xp(2);
        deltaz = Xf(3) - Xp(3);
        delta0 = [deltax,deltay,deltaz];
        slipVeloSpherical(i).rho = norm(delta0);
        deltaZ = dot(delta0,Vp_subs)/norm(Vp_subs);
        slipVeloSpherical(i).theta = acos(deltaZ/norm(delta0));
        
        clear Vf_local_mean Vp_local_mean
    end
end
