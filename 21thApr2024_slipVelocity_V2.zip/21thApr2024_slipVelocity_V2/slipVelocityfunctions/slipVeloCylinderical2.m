function slipVeloCylind = slipVeloCylinderical2(particle_part, tracers_part, neighborIdxAll, startTime, endTime, k)
% SLIPVELOCYLINDERICAL computes slip velocities in cylindrical coordinates
% for tracers near particles between specified start and end times.
%   slipVeloCylind = SLIPVELOCYLINDERICAL(particle_part, tracers_part,
%   neighborIdxAll, startTime, endTime, k) calculates slip velocities based
%   on input parameters and stores the results in the structure 'slipVeloCylind'.
%
%   Input:
%       particle_part   - Structure containing information about particles.
%       tracers_part    - Structure containing information about tracers.
%       neighborIdxAll  - Structure containing neighbor information.
%       startTime       - Start time for slip velocity calculation.
%       endTime         - End time for slip velocity calculation.
%       k               - Frame-related parameter for calculations.
%
%   Output:
%       slipVeloCylind  - Structure containing slip velocity information.
%           .rho        - Radial distance in cylindrical coordinates.
%           .theta      - Azimuthal angle in cylindrical coordinates.
%           .z          - Axial distance in cylindrical coordinates.
%           .Urel       - Relative slip velocity in cylindrical coordinates.
%

    Nframemax = 1e6;

    % Set default value for frame-related parameter
    kexp = 1;
    if nargin > 5
        kexp = k;
    end

    % Calculate start and end times within the frame limit
    tstart = mod(startTime(kexp), Nframemax);
    tend = mod(endTime(kexp), Nframemax);

    % Initialize structure to store slip velocity information
    slipVeloCylind = struct('rho',[], 'theta',[], 'z',[], 'Urel',[]);

    % Prepare indices for searching
    idx_front_back = sort(vertcat(neighborIdxAll(tstart:tend).idx));

    % Iterate over indices
    for i = 1:numel(idx_front_back)
        idxp = particle_part.Tf == tracers_part.Tf(idx_front_back(i));
        idxt = idx_front_back(i);

        % Extract position and velocity information for particles and tracers
        Xp = [particle_part.Xf(idxp), particle_part.Yf(idxp), particle_part.Zf(idxp)];
        Vp = [particle_part.Vx(idxp), particle_part.Vy(idxp), particle_part.Vz(idxp)];
        Xf = [tracers_part.Xf(idxt), tracers_part.Yf(idxt), tracers_part.Zf(idxt)];
        Uf = [tracers_part.Vx(idxt), tracers_part.Vy(idxt), tracers_part.Vz(idxt)];
        
        % Normalize particle velocity vector
        normVp = Vp/norm(Vp);

        % Calculate rotation matrix that used to align the particle
        % velocity to the third component of coordinates (z)
        R = rotationMatrix(Vp, [0,0,1]);

        % compute the coordinates in particle framework
        % it's actually a cylindrical coordinate
        z_cart = (Xf-Xp)*Vp'/norm(Vp)*normVp;
        rho_cart = (Xf-Xp)-z_cart;
        
        %  transform in to the coordinates with particle velocity being 
        % the positive z-axis
        z = (R*z_cart')';
        rho = (R*rho_cart')';
        
        % Store computed values in the slipVeloCylind structure
        slipVeloCylind(i,:).z = z(3);
        slipVeloCylind(i,:).rho = norm(rho);
        slipVeloCylind(i,:).theta = NaN;
        
        % the same for velocity
        Urel_cart = Uf-Vp;
        slipVeloCylind(i,:).Urel = (R*Urel_cart')';
    end
end
