function parfor_saveSlipVeloData(kexp,fpathT_tracks,fpathP_tracks,startTime,endTime,Rmin,Rmax,fmatEulerStats,n,fpathP_slipVeloData)


fname = ['tracks_' num2str(kexp) '.mat'];
load([fpathT_tracks fname],'tracklong_tracers') % particle's trajectory struct
load([fpathP_tracks fname],'tracklong_particle') % tracers's trajectory struct

if size(tracklong_particle,2)>1
    tracklong_particle = mergeStructures(tracklong_particle);
end

% convert from 1*N structure(sorted by different tracks) to 1*1 structure
particle_part = convertTrack(tracklong_particle); 
tracer_part = convertTrack(tracklong_tracers);

% find terminal state where a ~= 0, set the RelThres to a large value
% to include the whole trajectory from the beginning  
%     [maxTimeLength, startTime, endTime, ThresErrorTS] = findTimeRange(particle_part.Ay, 100);
startTime0 = startTime;
endTime0 = min(endTime,numel(particle_part.Tf));
% startTime0 = 1;
% endTime0 = numel(particle_part.Tf);

% returns the vertical particle settling velcoity in terminal state
Vpg(kexp,1) = mean(particle_part.Vy(startTime0:endTime0));

% find the index of neighboring tracers of big particle at each frame
neighborIdxAll = neighbor(particle_part,tracer_part,Rmin,Rmax,kexp);

% returns the relative slip velocity in Spherical coordinates
slipVelo = slipVelo_v2(particle_part,tracer_part,neighborIdxAll,startTime0,endTime0,'Spacing',fmatEulerStats,n); % or figEuler

save([fpathP_slipVeloData 'slipVelo_',num2str(kexp),'.mat'],'neighborIdxAll','slipVelo','Rmin','Rmax','startTime0','endTime0');
clear neighborIdxAll slipVelo particle_part tracer_part tracklong_particle tracklong_tracers