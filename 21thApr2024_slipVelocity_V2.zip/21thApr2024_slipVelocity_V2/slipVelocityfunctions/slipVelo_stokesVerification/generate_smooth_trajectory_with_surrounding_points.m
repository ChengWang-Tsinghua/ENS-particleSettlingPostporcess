function [xx, yy, zz, aa, bb, cc] = generate_smooth_trajectory_with_surrounding_points(xRange, yRange, zRange, numPoints, D)
    % Set default values if not provided
    if nargin < 5
        D = 1; % Default distance limit
    end
    if nargin < 4
        numPoints = 100;
    end
    if nargin < 3
        zRange = [0, 10];
    end
    if nargin < 2
        yRange = [0, 10];
    end
    if nargin < 1
        xRange = [0, 10];
    end

    % Generate smooth trajectory
    [xx, yy, zz] = randSmoothTraj(xRange, yRange, zRange, numPoints);

    % Generate random coordinates surrounding each point
    numSurroundingPoints = 10; % Number of surrounding points
    [theta, phi] = meshgrid(linspace(0, 2*pi, numSurroundingPoints), linspace(0, pi, numSurroundingPoints));
    theta = theta(:);
    phi = phi(:);
    [dx, dy, dz] = sph2cart(theta, phi, D);

    aa = zeros(numPoints * numSurroundingPoints, 1);
    bb = zeros(numPoints * numSurroundingPoints, 1);
    cc = zeros(numPoints * numSurroundingPoints, 1);

    % Generate random coordinates surrounding each point
    for i = 1:numPoints
        for j = 1:numSurroundingPoints
            index = (i - 1) * numSurroundingPoints + j;
            aa(index) = xx(i) + dx(index);
            bb(index) = yy(i) + dy(index);
            cc(index) = zz(i) + dz(index);
        end
    end
end
