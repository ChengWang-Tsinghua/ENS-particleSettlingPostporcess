clear;clc;
close all
addpath(genpath('/Volumes/DISK-1/SDT_EXP'));

particleTraj = 400;

tracerNumPerFrame = 5000;

rp = 10;
Rmin = 0;
Rmax= 490;

%% generate random trajectory
% Define ranges and number of points
xRange = [-20, 20];
yRange = [-20, 20];
zRange = [-40, 40];


xx = ones(1,particleTraj)*mean(xRange);
yy = linspace(zRange(2),zRange(1),particleTraj);% 'Y' component is the gravity direction
zz = ones(1,particleTraj)*mean(yRange);

% % Generate trajectory
% % [xx, yy, zz] = randSmoothTraj(xRange, yRange, zRange, particleTraj);
% % Plot the trajectory
% figure;
% plot3(xx, zz, yy, 'b', 'LineWidth', 2);
% xlabel('X');
% ylabel('Y');
% zlabel('Z');
% axis equal
% title('Smooth 3D Trajectory of Particle with Decreasing Z');
% grid on;

tracklong_particle.Xf = xx;
tracklong_particle.Yf = yy;
tracklong_particle.Zf = zz;


% num_vectors = numel(xx);
% random_vectors = generate_random_unit_vectors(num_vectors);
    
% tracklong_particle.Vx = random_vectors(:,1);
% tracklong_particle.Vy = random_vectors(:,2);
% tracklong_particle.Vz = random_vectors(:,3);

tracklong_particle.Vx = tracklong_particle.Xf*0;
tracklong_particle.Vy = tracklong_particle.Xf*0 + 1;% 'Y' component is the gravity direction
tracklong_particle.Vz = tracklong_particle.Xf*0;

startTime = 50;
tracklong_particle.Tf = startTime:1:startTime+particleTraj-1;

%%
lenTraj = numel(xx);
min_radius = rp+Rmin;
max_radius = rp+Rmax;

r = zeros(lenTraj*tracerNumPerFrame,1)*NaN;
theta = zeros(lenTraj*tracerNumPerFrame,1)*NaN;
phi = zeros(lenTraj*tracerNumPerFrame,1)*NaN;

aa = zeros(lenTraj*tracerNumPerFrame,1)*NaN;
bb = zeros(lenTraj*tracerNumPerFrame,1)*NaN;
cc = zeros(lenTraj*tracerNumPerFrame,1)*NaN;

uR = zeros(lenTraj*tracerNumPerFrame,1)*NaN;
utheta = zeros(lenTraj*tracerNumPerFrame,1)*NaN;
Uz2D = zeros(lenTraj*tracerNumPerFrame,1)*NaN;
Ux2D = zeros(lenTraj*tracerNumPerFrame,1)*NaN;

vvxx = zeros(lenTraj*tracerNumPerFrame,1)*NaN;
vvyy = zeros(lenTraj*tracerNumPerFrame,1)*NaN;
vvzz = zeros(lenTraj*tracerNumPerFrame,1)*NaN;

ttff = zeros(lenTraj*tracerNumPerFrame,1)*NaN;

for i = 1:lenTraj
    index = (i-1)*tracerNumPerFrame+1:i*tracerNumPerFrame;
    [~, ~, ~, x0, y0, z0] = random_spherical_to_cartesian(min_radius, max_radius, tracerNumPerFrame);

    % ii = find(theta0>pi);
    % theta0(ii) = 2*pi-theta0(ii);
    
    % r(index) = r0;
    % theta(index) = theta0; % range [0,2*pi]
    % phi(index) = phi0; % range [0,pi]

    aa(index) = xx(i)+x0;
    bb(index) = yy(i)+y0; % 'Y' component is the gravity direction
    cc(index) = zz(i)+z0;
    
    r0 = sqrt(x0.^2+y0.^2+z0.^2);
    r(index) = r0;
    theta0 = acos(y0./sqrt(x0.^2+y0.^2+z0.^2));
    theta(index) = theta0;

    uR(index) = -cos(theta0).*(1-1.5*rp./r0+0.5*(rp./r0).^3);
    utheta(index) = sin(theta0).*(1-0.75*rp./r0-0.25*(rp./r0).^3); 

    Uz2D(index) = uR(index).*cos(theta0)-utheta(index).*sin(theta0);
    Ux2D(index) = uR(index).*sin(theta0)+utheta(index).*cos(theta0);

    vvxx(index) = 0+Ux2D(index);
    vvyy(index) = 1 + Uz2D(index);% 'Y' component is the gravity direction
    vvzz(index) = 0+0;

    ttff(index) = ones(tracerNumPerFrame,1)*(startTime+i-1);
    
    clear theta0 phi0 r0 x0 y0 z0
    % scatter3(xx(i),yy(i),zz(i));hold on
    % scatter3(x,y,z, 'filled')
end

tracklong_tracers.Xf = aa;
tracklong_tracers.Yf = bb;% 'Y' component is the gravity direction
tracklong_tracers.Zf = cc;
    
tracklong_tracers.Vx = vvxx;
tracklong_tracers.Vy = vvyy;% 'Y' component is the gravity direction
tracklong_tracers.Vz = vvzz;

tracklong_tracers.Tf = ttff;
%%
nbint = 100;
nbinr = 100;

[rr,tt,~,~,X,Y] = SphericalMesh([min_radius max_radius],nbinr,nbint);


meanUz2D = X*NaN;
meanUx2D = X*NaN;
for i = 1:nbinr-1
    for j =1:nbint-1
        idx = find(r>=rr(i) & r<rr(i+1) & theta>=tt(j) & theta<tt(j+1));
        meanUz2D(j,i) = mean(Uz2D(idx));
        meanUx2D(j,i) = mean(Ux2D(idx));
    end
end
%%
figure;
pcolor(X,Y,meanUz2D);
shading flat
xlabel('$z/\eta_K$',Interpreter='latex');
ylabel('$\rho/\eta_K$',Interpreter='latex');
colorbar;
clim([-1 0])
savefig(['stokesUz_Rp' num2str(rp) '_bin'])

%%
figure;
pcolor(X,Y,meanUx2D);
shading flat
xlabel('$z/\eta_K$',Interpreter='latex');
ylabel('$\rho/\eta_K$',Interpreter='latex');
colorbar;
clim([-0.1 0.1])
savefig(['stokesUx_Rp' num2str(rp) '_bin'])

%% check tracklong structure
numTf = numel(tracklong_particle.Tf);

rho_sph = tracklong_tracers.Xf*NaN;
theta_sph = tracklong_tracers.Xf*NaN;
phi_sph = tracklong_tracers.Xf*NaN;

urelx = tracklong_tracers.Vx*NaN;
urely = tracklong_tracers.Vx*NaN;% 'Y' component is the gravity direction
urelz = tracklong_tracers.Vx*NaN;
urel_projectVp = tracklong_tracers.Vx*NaN;

deltaRho = tracklong_tracers.Vx*NaN;
deltatheta = tracklong_tracers.Vx*NaN;

% theta2D = tracklong_tracers.Xf*NaN;
% rho2D = tracklong_tracers.Xf*NaN;

for i = 1:numTf
    tp = tracklong_particle.Tf(i);
    xp = tracklong_particle.Xf(i);
    yp = tracklong_particle.Yf(i);
    zp = tracklong_particle.Zf(i);
    vxp = tracklong_particle.Vx(i);
    vyp = tracklong_particle.Vy(i);
    vzp = tracklong_particle.Vz(i);

    idx = find(tracklong_tracers.Tf == tp);
    xf = tracklong_tracers.Xf(idx);
    yf = tracklong_tracers.Yf(idx);
    zf = tracklong_tracers.Zf(idx);
    vxf = tracklong_tracers.Vx(idx);
    vyf = tracklong_tracers.Vy(idx);
    vzf = tracklong_tracers.Vz(idx);
    
    Xp = [xp, yp, zp];
    Xf = [xf, yf, zf];

    Vp = [vxp, vyp, vzp];
    Vf = [vxf, vyf, vzf];

    for j = 1:numel(idx)
        index = idx(j);
        urelx(index) = Vf(j,1) - Vp(1);
        urely(index) = Vf(j,2) - Vp(2);% 'Y' component is the gravity direction
        urelz(index) = Vf(j,3) - Vp(3);

        urel_projectVp(index) = dot((Vf(j,:) - Vp),Vp)/norm(Vp);

        deltax = Xf(j,1) - Xp(1);
        deltay = Xf(j,2) - Xp(2);
        deltaz = Xf(j,3) - Xp(3);
        delta0 = [deltax,deltay,deltaz];
        deltaRho(index) = norm(delta0);
        deltaZ = dot(delta0,Vp)/norm(Vp);
        deltatheta(index) = acos(deltaZ/deltaRho(index));

    end
end

%%
meanUx_spherical = X*NaN;
meanUy_spherical = X*NaN;
meanU_projectVp_spherical = X*NaN;
for i = 1:nbinr-1
    for j = 1:nbint-1
        idx = find(deltaRho>=rr(i) & deltaRho<rr(i+1) & deltatheta>=tt(j) & deltatheta<tt(j+1));
        meanUx_spherical(j,i) = mean(urelx(idx));
        meanUy_spherical(j,i) = mean(urely(idx));% 'Y' component is the gravity direction
        meanU_projectVp_spherical(j,i) = mean(urel_projectVp(idx));
    end
end

%%
figure;
pcolor(X,Y,meanUy_spherical);
shading flat
xlabel('$z/\eta_K$',Interpreter='latex');
ylabel('$\rho/\eta_K$',Interpreter='latex');
colorbar;
clim([-1 0])
savefig(['stokesUz_Rp' num2str(rp) '_bin_trajStruct'])

%%
figure;
pcolor(X,Y,meanUx_spherical);
shading flat
xlabel('$z/\eta_K$',Interpreter='latex');
ylabel('$\rho/\eta_K$',Interpreter='latex');
colorbar;
clim([-0.1 0.1])
savefig(['stokesUx_Rp' num2str(rp) '_bin_trajStruct'])

%%
figure;
pcolor(X,Y,meanU_projectVp_spherical);
shading flat
xlabel('$z/\eta_K$',Interpreter='latex');
ylabel('$\rho/\eta_K$',Interpreter='latex');
colorbar;
clim([-1 0])
savefig(['stokesU_projectVp_Rp' num2str(rp) '_bin_trajStruct'])

%%
save('particle_tracks_101.mat',"tracklong_particle")
%%
save('tracer_tracks_101.mat',"tracklong_tracers")