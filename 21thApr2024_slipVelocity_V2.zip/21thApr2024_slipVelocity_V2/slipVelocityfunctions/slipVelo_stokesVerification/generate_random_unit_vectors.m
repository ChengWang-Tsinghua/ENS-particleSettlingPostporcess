function random_vectors = generate_random_unit_vectors(num_vectors)
    % Initialize an array to store the random vectors
    random_vectors = zeros(num_vectors, 3);

    % Generate random vectors
    for i = 1:num_vectors
        % Generate random values for each component
        x = randn();
        y = randn();
        z = randn();

        % Create the vector
        v = [x, y, z];

        % Normalize the vector to have unit length
        unit_v = v / norm(v);

        % Store the unit vector in the array
        random_vectors(i, :) = unit_v;
    end
end
