function [r, theta, phi, x, y, z] = random_spherical_to_cartesian(min_radius, max_radius, num_points)
    % Generate random spherical coordinates
    
    
    r = (max_radius - min_radius) * rand(num_points, 1) + min_radius; % Radius
    theta = 2*pi*rand(num_points, 1); % Azimuthal angle, range [0,2*pi]
    phi = acos(2*rand(num_points, 1) - 1); % Polar angle, range [0,pi]

    % Convert spherical coordinates to Cartesian coordinates
    x = r .* sin(phi) .* cos(theta);
    y = r .* sin(phi) .* sin(theta);
    z = r .* cos(phi);
end
