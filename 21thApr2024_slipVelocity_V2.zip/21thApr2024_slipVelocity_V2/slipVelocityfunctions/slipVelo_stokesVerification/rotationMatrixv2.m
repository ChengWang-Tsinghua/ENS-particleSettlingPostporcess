function R = rotationMatrixv2(v1, v2)
    % Normalize input vectors
    v1 = v1 / norm(v1);
    v2 = v2 / norm(v2);

    % Compute the axis of rotation
    axis = cross(v1, v2);
    axis = axis / norm(axis);

    % Compute the angle of rotation
    angle = acos(dot(v1, v2));

    % Compute the rotation matrix
    R = eye(3) + sin(angle) * skew(axis) + (1 - cos(angle)) * skew(axis)^2;
end

function S = skew(v)
    % Skew-symmetric matrix from vector
    S = [0 -v(3) v(2); v(3) 0 -v(1); -v(2) v(1) 0];
end
