function [xx, yy, zz] = randSmoothTraj(xRange, yRange, zRange, numPoints)
    % Set default values if not provided
    if nargin < 4
        numPoints = 100;
    end
    if nargin < 3
        zRange = [0, 10];
    end
    if nargin < 2
        yRange = [0, 10];
    end
    if nargin < 1
        xRange = [0, 10];
    end

    % Generate random points in 2D within the specified ranges
    x = rand(1, numPoints) * (xRange(2) - xRange(1)) + xRange(1);
    y = rand(1, numPoints) * (yRange(2) - yRange(1)) + yRange(1);

    % Generate decreasing z-values
    z = linspace(zRange(2), zRange(1), numPoints); % Z values decrease from zRange(2) to zRange(1)

    % Smooth the trajectory using spline interpolation
    t = 1:numPoints;
    tt = linspace(1, numPoints, 10*numPoints); % finer time grid for smooth curve
    xx = spline(t, x, tt);
    yy = spline(t, y, tt);
    zz = spline(t, z, tt);
end
