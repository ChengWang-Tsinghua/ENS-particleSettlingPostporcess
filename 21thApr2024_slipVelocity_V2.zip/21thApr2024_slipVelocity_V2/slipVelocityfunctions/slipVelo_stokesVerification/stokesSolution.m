clear;clc;close all
addpath(genpath('/Volumes/DISK-1/SDT_EXP'));
mycolormap = mycolor('#063970','#e28743');%('#063970','#eeeee4','#e28743')
color1 = '#000000';
color3 = [mycolormap(1,:);mycolormap((size(mycolormap,1)+1)/2,:);mycolormap(end,:)];
color5 = [mycolormap(1,:);mycolormap(round((size(mycolormap,1)+1)/4),:);mycolormap(round(2*(size(mycolormap,1)+1)/4),:);mycolormap(round(3*(size(mycolormap,1)+1)/4),:);mycolormap(end,:)];

set(groot, 'defaultAxesTickLabelInterpreter','latex'); 
set(groot, 'defaultTextInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');
set(groot, 'defaultLegendLocation','best');
set(groot, 'defaultAxesTitleFontWeight','bold')
set(groot,'defaultLegendAutoUpdate','off')

set(groot, 'defaultLineLineWidth',2)
set(groot,'defaultLineMarkerSize',8)
set(groot, 'defaultAxesFontSize',18)
set(groot, 'defaultLegendFontSize',12)
set(groot, 'defaultTextFontSize',15)

%%
nbinr = 100;
nbint = 100;
Rmax = 500;
rp = 10;

Rmin = rp;
[rr,pp,~,~,X,Y] = SphericalMesh([Rmin Rmax],nbinr,nbint);

R = linspace(Rmin,Rmax,nbinr);
theta = linspace(0,pi,nbint);


for i = 1:nbinr
    for j = 1:nbint
%         idxr = find(R>rr(i)& R<rr(i+1));
%         idxt = find(theta>tt(j)& theta<tt(j+1));
        uR(j,i) = -cos(theta(j))*(1-1.5*rp/R(i)+0.5*(rp/R(i))^3);
        utheta(j,i) = sin(theta(j))*(1-0.75*rp/R(i)-0.25*(rp/R(i))^3);    

        Uz2D(j,i) = uR(j,i)*cos(theta(j))-utheta(j,i)*sin(theta(j));
        Ux2D(j,i) = uR(j,i)*sin(theta(j))+utheta(j,i)*cos(theta(j));

        psi(j,i) = 0.25*1*(rp^3/R(i)-3*rp*R(i)+2*R(i)^2)*sin(theta(j))^2;
    end
end

%%
for i = 1:2
    if i == 1
        v =Uz2D;
        titlestr = ['$U_z$'];
        fnamestr = ['stokesUz_Rp' num2str(rp)];
        crange = [-1 0];
    else
        v =Ux2D;
        titlestr = ['$U_x$'];
        fnamestr = ['stokesUx_Rp' num2str(rp)];
        crange = [-0.1 0.1];
    end
    figure;
    pcolor(X,Y,v);shading flat
    hold on
    contour(X, Y, psi,100,'k--');
    % axis([-Rmax Rmax 0 Rmax])
    xlabel('$z/\eta_K$',Interpreter='latex');
    ylabel('$\rho/\eta_K$',Interpreter='latex');
    col =colorbar;
    caxis(crange)
    hold on
    % rectangle('Position', [[0, 0] - rp, 2*rp, 2*rp], 'Curvature', [1, 1], 'EdgeColor', 'b','FaceColor','k');
    % quiver(0, 0, rp*4, 0, 0, 'r', 'LineWidth', 3);

    title(titlestr)
    savefig(fnamestr)

    % figure
    % quiver(X,Y,Uz2D,Ux2D,1)
    % xlabel('$z/\eta_K$');
    % ylabel('$x/\eta_K$');
    % col =colorbar;
    % caxis(crange)
    % hold on
    % % rectangle('Position', [[0, 0] - rp, 2*rp, 2*rp], 'Curvature', [1, 1], 'EdgeColor', 'b','FaceColor','k');
    % % quiver(0, 0, rp*4, 0, 0, 'r', 'LineWidth', 3);
    % 
    % title(titlestr)

    % savefig_custom(pwd,fnamestr,14,7)

    pause(1)
end

