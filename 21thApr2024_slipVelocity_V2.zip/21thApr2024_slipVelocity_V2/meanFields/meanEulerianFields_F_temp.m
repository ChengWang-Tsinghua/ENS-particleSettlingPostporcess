function meanEulerianFields_F_temp(fin,Fs,dt,nbins,threshold,gridRange,fEulerStats,ftracks_subsMean,kexp)


load([fin 'tracks_' num2str(kexp) '.mat'],'tracklong_tracers');


%% Tracer: compute the mean fields and substract it
[~,~,FV,~] = meanFields_v2(tracklong_tracers,Fs,dt,nbins,threshold,1,1,gridRange);
[~,~,FVrms,~] = meanFields_v2(tracklong_tracers,Fs,dt,nbins,threshold,1,2,gridRange);
[~,~,FA,~] = meanFields_v2(tracklong_tracers,Fs,dt,nbins,threshold,2,1,gridRange);
[~,~,FArms,~] = meanFields_v2(tracklong_tracers,Fs,dt,nbins,threshold,2,2,gridRange);
% ------>>>>>>>>
% now the tracklong contains the rms fields
save([fEulerStats 'EulerianStats_' num2str(kexp) '.mat'], ...
    'FV','FVrms','FA','FArms','-append');  
