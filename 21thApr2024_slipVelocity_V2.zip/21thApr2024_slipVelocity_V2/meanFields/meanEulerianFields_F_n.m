function meanEulerianFields_F_n(fin,Fs,dt,nbins,threshold,gridRange,fout,k,n)

catTraj = [];
for i = (k-1)*n+1:k*n
    load([fin 'tracks_' num2str(i) '.mat'],'tracklong_tracers');
    catTraj = [catTraj tracklong_tracers];
    clear tracklong_tracers
end

%% Tracer: compute the mean fields and substract it
[~,~,FV,~] = meanFields_v2(catTraj,Fs,dt,nbins,threshold,1,1,gridRange);
[~,~,FVrms,~] = meanFields_v2(catTraj,Fs,dt,nbins,threshold,1,2,gridRange);
[~,~,FA,~] = meanFields_v2(catTraj,Fs,dt,nbins,threshold,2,1,gridRange);
[~,~,FArms,~] = meanFields_v2(catTraj,Fs,dt,nbins,threshold,2,2,gridRange);
% ------>>>>>>>>
% now the tracklong contains the rms fields
save([fout 'EulerianStats_' num2str(k) '.mat'],'FV','FVrms','FA','FArms');  
