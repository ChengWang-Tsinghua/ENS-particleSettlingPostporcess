function [z,B,dz,Bz_pred,Gz_pred] = computeBfield(fpath,filelist,Colis_Param,Z_ColisCenter)
for k = 1:length(filelist)
    CalibData = load([fpath, char(filelist(k)),'.txt']);
    z(:,k) = (CalibData(:,1)-Z_ColisCenter)*1e-3; % m
    B.x(:,k)  = CalibData(:,2); % Gauss
    B.y(:,k)  = CalibData(:,3); % Gauss
    B.z(:,k)  = CalibData(:,4); % Gauss

    B.r(:,k)  = sqrt(B.x(:,k).^2 + B.y(:,k).^2); % Gauss

    B.len(:,k)  = sqrt(B.x(:,k).^2 + B.y(:,k).^2 + B.z(:,k).^2);

    clear CalibData
end
dz = z(2,1)-z(1,1);

save([fpath filesep 'Bfields.mat'],'z','B','dz','Colis_Param');

%%
[~,Bz_pred] = B_pred(Colis_Param,z(:,1));
Gz_pred = diff(Bz_pred)./diff(z(:,1));
