clc;clear;
close all
addpath(genpath('/Volumes/DISK-1/SDT_EXP/matlab/Cheng'));
mycolormap1 = mycolor('#0000B2','#FFFFFF','#B10000');

set(groot, 'defaultAxesTickLabelInterpreter','latex'); 
set(groot, 'defaultTextInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');
set(groot, 'defaultLegendLocation','best');
set(groot, 'defaultAxesTitleFontWeight','bold')
set(groot,'defaultLegendAutoUpdate','off')

set(groot, 'defaultLineLineWidth',2)
set(groot,'defaultLineMarkerSize',8)
set(groot, 'defaultAxesFontSize',18)
set(groot, 'defaultLegendFontSize',12)
set(groot, 'defaultTextFontSize',15)

%%
figPath = '/Volumes/DISK-1/dataENSLyon/magneticFieldsCalib/';
%% position values in the stage coordinate
Z_ColisCenter =90; %center of the coli sets instead of the geometric center of the tank

image_bot = 95;
image_top = 171;

cam_pos = 133; % find with set_0.PY, equals to the center of the images

traj_bot = 95; % roughly equals to the postion of the bottom of the image
traj_top = 167; % roughly equals to the postion of the end of the tube
% length of the trajectories is around 68~70 mm 

%% position values in the colis' coordinate
image_bot = (image_bot - Z_ColisCenter)*1e-3;
image_top = (image_top - Z_ColisCenter)*1e-3;

cam_pos = (cam_pos - Z_ColisCenter)*1e-3;

traj_bot = (traj_bot - Z_ColisCenter)*1e-3;
traj_top = (traj_top - Z_ColisCenter)*1e-3;

%%

Colis_Param_constB = {};

% Z6-Z1
Colis_Param_constB.R = [16.3000   22.1000   15.6000   15.4000   21.8000   16.1000]*1e-2; % m
Colis_Param_constB.N = [965   103   450   452   101   969];

Colis_Param_microg = Colis_Param_constB;
Colis_Param_hyperg = Colis_Param_constB;

dR= 0.005; % m
%%
Colis_Param_constB.I =  [-0.10,  0.75,  0.06,   0.22,   0.75,   -0.39];
Colis_Param_constB.Z = [26.5000   24.5000   12.0000  -12.0000  -24.5000  -26.5000]*1e-2; % m

Colis_Param_microg.I =  [2.0  0.25  1.79  -0.15  -0.25  -2.43]*2;
Colis_Param_microg.Z = [26.5000   24.5000   12.0000  -12.0000  -24.5000  -26.5000]*1e-2; % m

Colis_Param_hyperg.I =  [-0.85,  0.48,  0.25,   0.50,   0.75,   0.608];
Colis_Param_hyperg.Z = [26.5000   24.5000   12.0000  -12.0000  -24.5000  -26.5000]*1e-2; % m

%%
fpath_constB = '/Volumes/DISK-1/dataENSLyon/magneticFieldsCalib/3-MageticData-ConstantB/';
filelist_constB = {'calibration_10_39_51';...
                'calibration_10_54_56';...
                'calibration_11_09_38';...
                'calibration_11_24_21';...
                'calibration_11_38_49';...
                'calibration_11_53_10';...
                'calibration_12_07_28';...
                'calibration_13_03_57';...
                'calibration_13_20_01';...
                'calibration_13_34_13';...
                'calibration_13_48_33'};

fpath_microg = '/Volumes/DISK-1/dataENSLyon/magneticFieldsCalib/1-MageticData-Microgravity/';
filelist_microg = {'calibration_14_52_53';...
            'calibration_09_44_18';...
            'calibration_15_18_20';...
            'calibration_10_15_54';...
            'calibration_10_31_56';...
            'calibration_10_47_06';...
            'calibration_11_02_08';...
            'calibration_11_17_35';...
            'calibration_11_33_10';...
            'calibration_11_47_59';
            'calibration_13_54_18'};
fpath_hyperg = '/Volumes/DISK-1/dataENSLyon/magneticFieldsCalib/2-MageticData-HyperGravity/';
filelist_hyperg = {'calibration_16_44_18';...
                'calibration_17_35_45';...
                'calibration_17_57_08';...
                'calibration_18_14_13';...
                'calibration_18_30_26';...
                'calibration_18_47_25';...
                'calibration_19_04_09';...
                'calibration_19_23_16';...
                'calibration_19_40_39';...
                'calibration_09_45_58';...
                'calibration_10_02_02'};

%%
[z_constB,B_constB,dz_constB,Bz_pred_constB,Gz_pred_constB] = computeBfield(fpath_constB,filelist_constB,Colis_Param_constB,Z_ColisCenter);

[z_microg,B_microg,dz_microg,Bz_pred_microg,Gz_pred_microg] = computeBfield(fpath_microg,filelist_microg,Colis_Param_microg,Z_ColisCenter);

[z_hyperg,B_hyperg,dz_hyperg,Bz_pred_hyperg,Gz_pred_hyperg] = computeBfield(fpath_hyperg,filelist_hyperg,Colis_Param_hyperg,Z_ColisCenter);

color0 = mycolormap1(1:floor(size(mycolormap1,1)/min(size(B_constB.z))):end,:);

%% B profile
figure 
t=tiledlayout(3,2,'TileSpacing','loose');
for i =1:3
    if i==1
        z = z_constB;
        B = B_constB;
        dz = dz_constB;
        Bz_pred = Bz_pred_constB;
        Gz_pred = Gz_pred_constB;
        fpath = fpath_constB;
        filelist = filelist_constB;
    elseif i==2
        z = z_microg;
        B = B_microg;
        dz = dz_microg;
        Bz_pred = Bz_pred_microg;
        Gz_pred = Gz_pred_microg; 
        fpath = fpath_microg;
        filelist = filelist_microg;
    elseif i==3
        z = z_hyperg;
        B = B_hyperg;
        dz = dz_hyperg;
        Bz_pred = Bz_pred_hyperg;
        Gz_pred = Gz_pred_hyperg; 
        fpath = fpath_hyperg;
        filelist = filelist_hyperg;
    end

    [dBzdr, dBzdz] = gradient(B.z,dR,dz);
    [dBrdr, dBrdz] = gradient(B.r,dR,dz);
    mean_dBzdz = mean(dBzdz(z>traj_bot&z<traj_top));
    save([fpath filesep 'Bfields.mat'],'mean_dBzdz','-append')
    
    if i==1
        dBzdr_constB = dBzdr;
        dBzdz_constB = dBzdz;
        dBrdr_constB = dBrdr;
        dBrdz_constB = dBrdz;
    elseif i==2
        dBzdr_microg = dBzdr;
        dBzdz_microg = dBzdz;
        dBrdr_microg = dBrdr;
        dBrdz_microg = dBrdz;
    elseif i==3
        dBzdr_hyperg = dBzdr;
        dBzdz_hyperg = dBzdz;
        dBrdr_hyperg = dBrdr;
        dBrdz_hyperg = dBrdz;
    end

    kk = find(abs(Bz_pred) == min(abs(Bz_pred)));
    kk_cam_pos = find(abs(z-cam_pos) == min(abs(z-cam_pos)));
    Z_height = z(1)-z(kk);
    
    nexttile;
    plot(z(:,1),Bz_pred,'LineWidth',2)
    hold on 
    for k = 1:min(size(B.z))
        plot(z(:,k),B.z(:,k),'o','LineWidth',2,Color=color0(k,:))
    end
    axis tight
    xlim([-0.095 0.135])
    xlabel('$z$ [m]',FontSize=25,FontName='Times New Roman',Interpreter='latex')
    ylabel('$B_z$ [G]',FontSize=25,FontName='Times New Roman',Interpreter='latex')
    if i == 1
        ylim([0.5 1.5])
    end
    if i == 1
        legend('Theory','r=0',...
            'r=+0.005m','r=+0.010m', ...
            'r=+0.015m','r=+0.020m', ...
            'r=+0.025m','r=+0.030m', ...
            'r=+0.035m','r=+0.040m', ...
            'r=+0.045m','r=+0.050m','Location','northoutside','NumColumns',2,'AutoUpdate','off')
    end
    yline(0,'r--')
    if i~=1
        xline(z(kk),'r--')
    end
    xline(cam_pos,'k--')
    
    patch([image_bot image_bot image_top image_top], [min(ylim) max(ylim) max(ylim) min(ylim)],mycolor('#FFFFFF'),EdgeColor = 'b')
    alpha(0)
    patch([traj_bot traj_bot traj_top traj_top], [min(ylim) max(ylim) max(ylim) min(ylim)],mycolor('#a155b9'),EdgeColor = 'none')
    alpha(0.2)

    %%
    nexttile;
    plot(z(1:end-1,1),Gz_pred,'LineWidth',2)
    hold on
    for k = 1:length(filelist)
        plot(z(:,k),dBzdz(:,k),'o','LineWidth',2,Color=color0(k,:))
    end
    axis tight
    xlim([-0.095 0.135])
    xlabel('$z$ [m]',FontSize=25,FontName='Times New Roman',Interpreter='latex')
    ylabel('$\nabla_z B_z$ [G/m]',FontSize=25,FontName='Times New Roman',Interpreter='latex')
    
    if i~=1
        xline(z(kk),'r--')
    end
    xline(cam_pos,'k--')
    
    patch([image_bot image_bot image_top image_top], [min(ylim) max(ylim) max(ylim) min(ylim)],mycolor('#FFFFFF'),EdgeColor = 'b')
    alpha(0)
    patch([traj_bot traj_bot traj_top traj_top], [min(ylim) max(ylim) max(ylim) min(ylim)],mycolor('#a155b9'),EdgeColor = 'none')
    alpha(0.2)
end
% savefig_custom(figPath,'Bfield',15,12)

%% g map
% 400micron cube
% B_rem = 1.24; % Tesla
% mass = 0.001e-3; % kg
% V = (0.4e-3)^3; % m^3
% miu0 = 4*pi*10^-7;% constant
% M = B_rem*V/miu0;

% 1mm sphere
B_rem = 1.17; % Tesla
mass = 0.0048e-3; % kg
d = 1e-3; % m
V = 4/3*pi*(d/2)^3; % m^3
miu0 = 4*pi*10^-7; % constant
M = B_rem*V/miu0;

g = 9.8;

figure
t=tiledlayout(1,3,'TileSpacing','loose');
for i =1:3
    if i==1
        z = z_constB;
        B = B_constB;
        filelist = filelist_constB;
        dBzdr = dBzdr_constB;
        dBzdz = dBzdz_constB;
        dBrdr = dBrdr_constB;
        dBrdz = dBrdz_constB;
        LevelStep_g = 0.005;
    elseif i==2
        z = z_microg;
        B = B_microg;
        filelist = filelist_microg;
        dBzdr = dBzdr_microg;
        dBzdz = dBzdz_microg;
        dBrdr = dBrdr_microg;
        dBrdz = dBrdz_microg;
        LevelStep_g = 0.02;
    elseif i==3
        z = z_hyperg;
        B = B_hyperg;
        filelist = filelist_hyperg;
        dBzdr = dBzdr_hyperg;
        dBzdz = dBzdz_hyperg;
        dBrdr = dBrdr_hyperg;
        dBrdz = dBrdz_hyperg;
        LevelStep_g = 0.02;
    end

    r = [0:dR:dR*(length(filelist)-1)]'; % m 
    dBdz = (B.r.*dBrdz + B.z.*dBzdz)./B.len;
    dBdr = (B.r.*dBrdr + B.z.*dBzdr)./B.len;

    [X1,Y1] = meshgrid(z(:,1),[0:dR:dR*(length(filelist)-1)]);
    X1 = X1';
    Y1 = Y1';

    g_eff = g-M*dBdz/10^4*1/mass;
    g_ratio = g_eff/g; 
    nexttile
    contourf(Y1,X1,g_ratio,'ShowText','on',LevelStep=LevelStep_g)
    hold on
    yline(image_top,'b--',LineWidth=2)
    yline(image_bot,'b--',LineWidth=2)
    yline(traj_top,'r--',LineWidth=2)
    yline(traj_bot,'r--',LineWidth=2)
    colorbar
    colormap("summer")
    ylim([-0.085 0.115])
    ylabel('$z$ [m]',FontSize=25,FontName='Times New Roman',Interpreter='latex')
    xlabel('$r$ [m]',FontSize=25,FontName='Times New Roman',Interpreter='latex')
    % title('$g_{eff}/g$',FontSize=20,FontName='Times New Roman',Interpreter='latex')

end

savefig_custom(figPath,'gMap',14,7)

%% Force map
for i =1:3
    if i==1
        z = z_constB;
        B = B_constB;
        filelist = filelist_constB;
        dBzdr = dBzdr_constB;
        dBzdz = dBzdz_constB;
        dBrdr = dBrdr_constB;
        dBrdz = dBrdz_constB;
        LevelStep_F = 20;
        fnamestr = 'ForceMap_constB';
    elseif i==2
        z = z_microg;
        B = B_microg;
        filelist = filelist_microg;
        dBzdr = dBzdr_microg;
        dBzdz = dBzdz_microg;
        dBrdr = dBrdr_microg;
        dBrdz = dBrdz_microg;
        LevelStep_F = 0.05;
        fnamestr = 'ForceMap_microg';
    elseif i==3
        z = z_hyperg;
        B = B_hyperg;
        filelist = filelist_hyperg;
        dBzdr = dBzdr_hyperg;
        dBzdz = dBzdz_hyperg;
        dBrdr = dBrdr_hyperg;
        dBrdz = dBrdz_hyperg;
        LevelStep_F = 0.05;
        fnamestr = 'ForceMap_hyperg';
    end

    r = [0:dR:dR*(length(filelist)-1)]'; % m 
    dBdz = (B.r.*dBrdz + B.z.*dBzdz)./B.len;
    dBdr = (B.r.*dBrdr + B.z.*dBzdr)./B.len;

    kk_cam_pos = find(abs(z-cam_pos) == min(abs(z-cam_pos)));

        ratio_zz = dBdz/dBdz(kk_cam_pos(1),1);
    %     ratio_rz = 1- dBdr/dBdz(kk003(1),1);
        ratio_rz = dBdr/dBdz(kk_cam_pos(1),1);
    
    [X1,Y1] = meshgrid(z(:,1),[0:dR:dR*(length(filelist)-1)]);
    X1 = X1';
    Y1 = Y1';
    figure
    t=tiledlayout(1,2,'TileSpacing','loose');
    nexttile
    % pcolor(Y1,X1,ratio_zz);shading interp
    contourf(Y1,X1,ratio_zz,'ShowText','on',LevelStep=LevelStep_F)
    hold on
    yline(image_top,'b--',LineWidth=2)
    yline(image_bot,'b--',LineWidth=2)
    yline(traj_top,'r--',LineWidth=2)
    yline(traj_bot,'r--',LineWidth=2)
    ylim([-0.085 0.115])
    colorbar
    ylabel('$z$ [m]',FontSize=20,FontName='Times New Roman',Interpreter='latex')
    xlabel('$r$ [m]',FontSize=20,FontName='Times New Roman',Interpreter='latex')
    % title('$F_z(r,z)/F_z(0,z_{cam})$',FontSize=20,FontName='Times New Roman',Interpreter='latex')
    
    nexttile
    %     pcolor(Y1,X1,ratio_rz);shading interp
    contourf(Y1,X1,ratio_rz,'ShowText','on',LevelStep=LevelStep_F)
    hold on
    yline(image_top,'b--',LineWidth=2)
    yline(image_bot,'b--',LineWidth=2)
    yline(traj_top,'r--',LineWidth=2)
    yline(traj_bot,'r--',LineWidth=2)
    ylim([-0.085 0.115])
    colormap("summer")
    colorbar
    ylabel('$z$ [m]',FontSize=20,FontName='Times New Roman',Interpreter='latex')
    xlabel('$r$ [m]',FontSize=20,FontName='Times New Roman',Interpreter='latex')

    savefig_custom(figPath,fnamestr,10,7)
end




