function targetStruct = copyStructFields(sourceStruct)
    % 确保输入参数为结构体
    if ~isstruct(sourceStruct)
        error('输入参数必须为结构体');
    end

    % 获取源结构体的字段名
    fieldNames = fieldnames(sourceStruct);

    % 创建一个空结构体
    targetStruct = struct();

    % 将源结构体的字段复制到目标结构体中
    for i = 1:numel(fieldNames)
        fieldName = fieldNames{i};
        targetStruct.(fieldName) = sourceStruct.(fieldName);
    end
end
