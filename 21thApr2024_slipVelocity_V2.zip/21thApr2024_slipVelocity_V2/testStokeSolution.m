%% test stokes solution
clear all;clc;close all

%% settings for plots

Fs = 2996;
Nexp = 100;

addpath(genpath('/Volumes/DISK-1/SDT_EXP'));
mycolormap = mycolor('#063970','#e28743');%('#063970','#eeeee4','#e28743')
mycolormap2 = mycolor('#063970','#eeeee4','#e28743');
color1 = '#000000';
color3 = [mycolormap(1,:);mycolormap((size(mycolormap,1)+1)/2,:);mycolormap(end,:)];
color5 = [mycolormap(1,:);mycolormap(round((size(mycolormap,1)+1)/4),:);mycolormap(round(2*(size(mycolormap,1)+1)/4),:);mycolormap(round(3*(size(mycolormap,1)+1)/4),:);mycolormap(end,:)];

set(groot, 'defaultAxesTickLabelInterpreter','latex'); 
set(groot, 'defaultTextInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');
set(groot, 'defaultLegendLocation','best');
set(groot, 'defaultAxesTitleFontWeight','bold')
set(groot,'defaultLegendAutoUpdate','off')

set(groot, 'defaultLineLineWidth',2)
set(groot,'defaultLineMarkerSize',8)
set(groot, 'defaultAxesFontSize',18)
set(groot, 'defaultLegendFontSize',12)
set(groot, 'defaultTextFontSize',15)

fpathT = [pwd filesep 'tracers' filesep];
fpathP = [pwd filesep 'particle' filesep];

fpathT_tracks = [fpathT 'Tracks' filesep];
fpathP_tracks = [fpathP 'Tracks' filesep];

figEuler = [fpathT 'Figures_Euler' filesep];

fpathP_slipVeloData = [pwd filesep 'slipVeloData' filesep];
mkdir(fpathP_slipVeloData)

%%
Rmin = 0;
Rmax = 500; %% stokes solution

for kexp = 101:101 
    fname = ['tracks_' num2str(kexp) '.mat'];
    load([fpathT_tracks fname],'tracklong_tracers') % particle's trajectory struct
    load([fpathP_tracks fname],'tracklong_particle') % tracers's trajectory struct

    if size(tracklong_particle,2)>1
        tracklong_particle = mergeStructures(tracklong_particle);
    end
    
    particle_part = convertTrack(tracklong_particle); 
    tracer_part = convertTrack(tracklong_tracers);
    
    startTime0 = 1;
    endTime0 = 400; 

    Vpg(kexp,1) = mean(particle_part.Vy(startTime0:endTime0));
    neighborIdxAll = neighbor(particle_part,tracer_part,Rmin,Rmax,1);
    slipVelo = slipVelo_Spherical_system(particle_part,tracer_part,neighborIdxAll,startTime0,endTime0,[]);

    save([fpathP_slipVeloData 'slipVeloSpherical_1.mat'],'neighborIdxAll','slipVelo');
    clear neighborIdxAll slipVelo particle_part tracer_part tracklong_particle tracklong_tracers
end

%% BOTH: slip velocity averaged over experiments

nbinr = 200;
nbint = 30;
nidxmax = 10000;

for kexp = 1:1 
    urel_allMatrices.x{:,kexp} = zeros(nbint,nbinr,nidxmax)*NaN;
    urel_allMatrices.y{:,kexp} = zeros(nbint,nbinr,nidxmax)*NaN;
    urel_allMatrices.z{:,kexp} = zeros(nbint,nbinr,nidxmax)*NaN;
    urel_allMatrices.projectVp{:,kexp} = zeros(nbint,nbinr,nidxmax)*NaN;
end
fieldname = fieldnames(urel_allMatrices);

[rr,tt,~,~,X,Y] = SphericalMesh([Rmin Rmax],nbinr,nbint);

for kexp = 1:1
    fname = ['slipVelo_',num2str(kexp),'.mat'];
    load([fpathP_slipVeloData fname],'slipVelo')
    
    % Extract relevant columns from slip velocity data
    rho = vertcat(slipVelo.rho);
    theta = vertcat(slipVelo.theta);
    urel = vertcat(slipVelo.urel);
    urel_projectVp = vertcat(slipVelo.urel_projectVp);

    urel0.x = urel(:,1); 
    urel0.y = urel(:,2);  % gravity direction
    urel0.z = urel(:,3); 
    urel0.projectVp = urel_projectVp; 

    for i = 1:nbinr-1
        for j = 1:nbint-1
            ind = find(rho >= rr(i) & rho < rr(i+1) & theta >= tt(j) & theta< tt(j+1));
            if numel(ind)~=0
                for kf = 1:numel(fieldname)
                    extendedVector = nan(1, nidxmax);
                    extendedVector(1:numel(ind)) = urel0.(fieldname{kf})(ind);
                    urel_allMatrices.(fieldname{kf}){:,kexp}(j,i,:) = extendedVector;
                end
            end
            
        end
    end

end

for i = 1:numel(fieldname)
    [averMeanUrel.(fieldname{i}), averStdUrel.(fieldname{i}),countUrel] = averUrelMap(urel_allMatrices.(fieldname{i}));
end
clear urel_allMatrices

save([fpathP_slipVeloData 'averUrel.mat'],'averMeanUrel','averStdUrel','countUrel')

%% Plot the binned mean values using pseudocolor

etaKMMS  = 1;
Vpg_tsABS = 1;
subscripts = {'x','y','z','proj'};
fnamesub = {'x','y','z','proj'};
%

figure;
% pcolor(X/etaKMMS,Y/etaKMMS, averMeanUrel.projectVp/Vpg_tsABS);
pcolor(X/etaKMMS,Y/etaKMMS, averMeanUrel.y/Vpg_tsABS);
xlabel('$z/\eta_K$',Interpreter='latex');
ylabel('$\rho/\eta_K$',Interpreter='latex');
colormap("parula")
col =colorbar;
colstr = ['$\langle U^{rel}_{proj}\rangle_{t,\phi}$'];
ylabel(col,colstr,'interpreter','latex')
col.TickLabelInterpreter = "latex";
hold on
patch(cos(linspace(0,pi)) * 0.5/etaKMMS, sin(linspace(0,pi)) * 0.5/etaKMMS, 'k');
col.TickLabelInterpreter = "latex";

clim([-1 0])
axis([-1 1 0 1]*200)
shading flat