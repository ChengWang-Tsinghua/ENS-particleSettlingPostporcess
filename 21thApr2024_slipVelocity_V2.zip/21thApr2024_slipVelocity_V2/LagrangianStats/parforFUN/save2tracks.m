function save2tracks(i,fpathT_STB,fmatTracks,fmatLagrStats,ifParticle,frame0,long_thres,wopt,lopt,s,w,Fs)

fnamein = ['STB_' num2str(i) '.mat'];
[track,Ilong] = buildTracks(fpathT_STB,fnamein,ifParticle,frame0,long_thres);

% Particle: Estimate smoothed tracks with optimal filter width
tracklong_tracers=calcVelLEM(track(Ilong),wopt,lopt,Fs);
Ine=arrayfun(@(X)(~isempty(X.Vx)),tracklong_tracers)==1;
tracklong_tracers = tracklong_tracers(Ine);

fnameout1 = ['tracks_' num2str(i) '.mat'];
save([fmatTracks filesep fnameout1],'long_thres','tracklong_tracers','wopt','lopt','Fs')

fnameout2 = ['LagrangianStats_' num2str(i) '.mat'];
save([fmatLagrStats filesep fnameout2],'s','w','wopt','lopt')

clear track Ilong Ine