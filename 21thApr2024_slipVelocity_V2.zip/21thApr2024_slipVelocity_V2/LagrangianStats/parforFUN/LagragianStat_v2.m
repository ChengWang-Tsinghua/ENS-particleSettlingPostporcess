function LagragianStat_v2(fin,Fs,pdf,ndt,fout,kexp)

load([fin 'tracks_' num2str(kexp) '.mat'],'tracklong_tracers');


%% Tracer: PDFs of velocity and acceleration 
% Nbins = 256; % bins for PDF
% n = 10; % spacing for PDF

Nbins = pdf.Nbins;
n = pdf.n;

% disp('calculating PDFs')
fieldname1  = ['Vx';'Vy';'Vz';'Ax';'Ay';'Az'];
parfor i = 1:6
    parforPDF(tracklong_tracers,fieldname1,i,Nbins,n);
end
clear fieldname1

fieldname2  = ['pdfVx';'pdfVy';'pdfVz';'pdfAx';'pdfAy';'pdfAz'];
for i = 1:6
    load([pwd filesep 'pdf_' num2str(i) '.mat'],'funpdf');
    LagrangianStats.(fieldname2(i,:))= copyStructFields(funpdf);
    clear funpdf
end
clear fieldname2 funpdf
delete([pwd filesep 'pdf_*'])

%% Tracer: compute MSD 
% disp('calculating MSDs')
fieldname1  = ['Xf';'Yf';'Zf'];
parfor i = 1:3
    parforMSDs(tracklong_tracers,fieldname1,i)
end
clear fieldname1

fieldname2  = ['MSDx';'MSDy';'MSDz'];
for i = 1:3
    load([pwd filesep 'MSDs_' num2str(i) '.mat'],'MSD');
    LagrangianStats.(fieldname2(i,:))= copyStructFields(MSD);
    clear MSD
end
clear fieldname2
delete([pwd filesep 'MSDs_*'])

%% Tracer: Lagrangian 2nd SF
% disp('calculating S2L')
fieldname1  = ['Vx';'Vy';'Vz'];
parfor i = 1:3
    parforS2L(tracklong_tracers,fieldname1,i)
end
clear fieldname1

fieldname2  = ['S2Lx';'S2Ly';'S2Lz'];
for i = 1:3
    load([pwd filesep 'S2L_' num2str(i) '.mat'],'S2L');
    LagrangianStats.(fieldname2(i,:))= copyStructFields(S2L);
    clear S2L
end
clear fieldname2
delete([pwd filesep 'S2L_*'])

%% Tracer: correlation function (fit)

% disp('calculating Correlation functions')
fieldname1  = ['Vx';'Vy';'Vz';'Ax';'Ay';'Az'];
parfor i = 1:6
    parforCorr(tracklong_tracers,fieldname1,i)
end
clear fieldname1

fieldname2  = ['Ruux';'Ruuy';'Ruuz';'Raax';'Raay';'Raaz'];
for i = 1:6
    load([pwd filesep 'Corr_' num2str(i) '.mat'],'Corr');
    LagrangianStats.(fieldname2(i,:))= copyStructFields(Corr);
    clear Corr
end
clear fieldname2
delete([pwd filesep 'Corr_*'])

%% Tracer: correlation function -- dt method (denosied)
% ndts = [8 8 8]; % start points of correlation function ndt
% ndtl = [10 10 10]; % length of correlation function ndt

ndts = ndt.start;
ndtl = ndt.len;

% disp('calculating Correlation functions -- dt method')
[tau,corrv,corra] = dtCorr(tracklong_tracers,ndts,ndtl,Fs);

LagrangianStats.dtCorrvX.ndts = ndts;
LagrangianStats.dtCorrvX.ndtl = ndtl;
LagrangianStats.dtCorrvX.tau = tau.X';
LagrangianStats.dtCorrvX.corr = corrv.X';

LagrangianStats.dtCorrvY.ndts = ndts;
LagrangianStats.dtCorrvY.ndtl = ndtl;
LagrangianStats.dtCorrvY.tau = tau.Y';
LagrangianStats.dtCorrvY.corr = corrv.Y';

LagrangianStats.dtCorrvZ.ndts = ndts;
LagrangianStats.dtCorrvZ.ndtl = ndtl;
LagrangianStats.dtCorrvZ.tau = tau.Z';
LagrangianStats.dtCorrvZ.corr = corrv.Z';

LagrangianStats.dtCorraX.ndts = ndts;
LagrangianStats.dtCorraX.ndtl = ndtl;
LagrangianStats.dtCorraX.tau = tau.X';
LagrangianStats.dtCorraX.corr = corra.X';

LagrangianStats.dtCorraY.ndts = ndts;
LagrangianStats.dtCorraY.ndtl = ndtl;
LagrangianStats.dtCorraY.tau = tau.Y';
LagrangianStats.dtCorraY.corr = corra.Y';

LagrangianStats.dtCorraZ.ndts = ndts;
LagrangianStats.dtCorraZ.ndtl = ndtl;
LagrangianStats.dtCorraZ.tau = tau.Z';
LagrangianStats.dtCorraZ.corr = corra.Z';
clear ndts ndtl


%% Tracer: save Lagrangian Stats
save([fout 'LagrangianStats_' num2str(kexp) '.mat'],'LagrangianStats','-append')
% save([fout 'Corr_' num2str(kexp) '.mat'],'LagrangianStats')
% disp('---- Lagrangian Stats done ----')