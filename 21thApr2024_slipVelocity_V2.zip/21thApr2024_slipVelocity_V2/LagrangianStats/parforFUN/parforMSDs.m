function parforMSDs(tracklong_tracers,fieldname,i)
    MSD = structFunc_struct(tracklong_tracers,fieldname(i,:),2);
    save([pwd filesep 'MSDs_' num2str(i) '.mat'],'MSD')
end