function parforS2L(tracklong_tracers,fieldname,i)
    S2L = structFunc_struct(tracklong_tracers,fieldname(i,:),2);
    save([pwd filesep 'S2L_' num2str(i) '.mat'],'S2L')
end