function params = expParam(Fs,mp,dp,rhof,nu,geff,taup,Vpg_ts,epsilon,sigmau)
% compute turbulence quantities
% [ly,lx,Gamma,beta,taup0,Vg] = turb_param(mp,dp,rhof,nu,px,py,geff)
%
% INPUT:
% rhop: particle mass       (kg)
% dp: particle diameter     (m)
% rhof: fluid density       (kg/m3)
% nu: fluid viscosity       (m2/s)
% px: pixel size of image
% py: pixel size of image
% geff: ratio of the effective gravity to 9.8m/s2 
% taup: estimated from (V(t)-V0)/(Vs-V0)
% Vs: measured particle's terminal falling velocity (m/s)
% epsilon: disspation rate
% sigmau: rms value of the fluctuation velocity of fluid 
%
% OUTPUT:
% ly: domain length along gravity (vertical)                (m)
% lx: domain length in horizontal direction                 (m)
% Gamma: density ratio
% beta: 3*rho_f/(rho_f+2*rho_p)
% taup0: particle response time with linear approximation   (s)
% Vg: terminal settling velocity with linear approximation  (s)
%
% reference turbulence parameters
% mp = 0.0048e-3;%kg
% dp = 1.0094e-3;%m
% rhof = 1000; %kg/m3
% nv = 8.532e-7;%m2/s, @ 27 celsius
% geff = 1; %ratio to 9.8m/s2
% turb = turb_param(0.0048e-3,1.0094e-3,1000,8.532e-7,1)

%% measured values
geff = geff*9.8;
rhop = mp/(pi*4/3*(dp/2)^3); % Compute rhop directly
Gamma = rhop/rhof;
beta = 3/(1+2*Gamma);
Rep = abs(Vpg_ts*dp/nu);
Rouse = abs(Vpg_ts/sigmau);
Ug = sqrt(abs(Gamma-1)*geff*dp);
Galileo = Ug*dp/nu;
CD = 4*Galileo^2/(3*Rep^2);

%% fluid parameters:
eta = (nu^3/epsilon)^0.25;
lambda = sqrt(15*nu/epsilon)*sigmau;
tau_eta = sqrt(nu/epsilon);
Re_lambda = sigmau*lambda/nu;
Ti = abs(sigmau/Vpg_ts);

%% parameters from approximation 
taup_creep = dp^2/(12*nu*beta);
Vs_creep = (Gamma-1)/(Gamma+0.5)*taup_creep*geff; 

Stokes = taup/tau_eta;
Stokes_creep = taup_creep/tau_eta;

Rep_Stokes = Galileo^2/18;
CD_Stokes = 24/Rep;

Rep_BL2003 = Galileo^2*(22.5+Galileo^1.364)/(0.0258*Galileo^2.6973+2.81*Galileo^2.0307+18*Galileo^1.364+405);
CD_BL2003 = 24/Rep_BL2003*(1+0.150*Rep_BL2003^0.681)+0.407/(1+8710/Rep_BL2003);

% Store variables in params structure before returning
params.Fs = Fs;
params.mp = mp;
params.dp = dp;
params.rhop = rhop;
params.rhof = rhof;
params.geff = geff;
params.nu = nu;
params.taup = taup;
params.Vs = Vpg_ts; 
params.Gamma = Gamma;
params.beta = beta;
params.Rep = Rep;
params.Rouse = Rouse;
params.Ug = Ug;
params.Galileo = Galileo;
params.CD = CD;
params.eta = eta;
params.lambda = lambda;
params.tau_eta = tau_eta;
params.Re_lambda = Re_lambda;
params.Ti = Ti;
params.taup_creep = taup_creep;
params.Vs_creep = Vs_creep;
params.Stokes = Stokes;
params.Stokes_creep = Stokes_creep;
params.Rep_Stokes = Rep_Stokes;
params.CD_Stokes = CD_Stokes;
params.Rep_BL2003 = Rep_BL2003;
params.CD_BL2003 = CD_BL2003;
end
