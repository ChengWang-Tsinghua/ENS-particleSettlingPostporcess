function pdf=mkpdf5_loop(fpathT_tracks,Nexp,vname,fields,n,w)

% fpathT_tracks = ['.' filesep 'tracers' filesep 'Tracks' filesep];

% Nexp = 3;
% vname = 'tracklong_tracers';
% field  = 'Vx';
% n = 256;
% w=10;

nfields = numel(fields(:,1));

if nfields == 3
    emptyStruct = struct(fields(1,:),[],fields(2,:),[],fields(3,:),[]);
elseif nfields == 1
    emptyStruct = struct(fields(1,:),[],fields(2,:),[],fields(3,:),[]);
else
    error('chech the input fieldnames')
end

L = emptyStruct;
sum_moy = emptyStruct;
for kexp = 1:Nexp
    fname = ['tracks_' num2str(kexp) '.mat'];
    data = load([fpathT_tracks fname]).(vname); % particle's trajectory struct
    
    for kfield = 1:nfields
        L_kexp=arrayfun(@(X)(numel(X.(fields(kfield,:)))),data);
        sum_moy_kexp =sum(arrayfun(@(X)(mean(X.(fields(kfield,:)))),data).*L_kexp);
        L.(fields(kfield,:)) = [L.(fields(kfield,:)),L_kexp];
        sum_moy.(fields(kfield,:)) = [sum_moy.(fields(kfield,:)),sum_moy_kexp];
        clear L_kexp sum_moy_kexp
    end
    clear data
end
for kfield = 1:nfields
    moy.(fields(kfield,:)) = sum(sum_moy.(fields(kfield,:)))/sum(L.(fields(kfield,:)));
end

sum_sigma2 = emptyStruct;
for kexp = 1:Nexp
    fname = ['tracks_' num2str(kexp) '.mat'];
    data = load([fpathT_tracks fname]).(vname); % particle's trajectory struct
    
    for kfield = 1:nfields
        L_kexp=arrayfun(@(X)(numel(X.(fields(kfield,:)))),data);
        sum_sigma2_kexp = sum(arrayfun(@(X)(mean((X.(fields(kfield,:))-moy.(fields(kfield,:))).^2)),data).*L.(fields(kfield,:))(kexp));
        sum_sigma2.(fields(kfield,:)) = [sum_sigma2.(fields(kfield,:)),sum_sigma2_kexp];
        clear sum_sigma2_kexp
    end
    clear data
end
for kfield = 1:nfields
    sigma.(fields(kfield,:)) = sqrt(sum(sum_sigma2.(fields(kfield,:)))/sum(L.(fields(kfield,:))));
end



for kfield = 1:nfields
    mm = moy.(fields(kfield,:)) -w*sigma.(fields(kfield,:));
    MM = moy.(fields(kfield,:)) +w*sigma.(fields(kfield,:));
    Xx.(fields(kfield,:))=linspace(mm,MM,n);
    Nx.(fields(kfield,:))=zeros(1,n);
end

NNx = emptyStruct;
for kexp = 1:Nexp
    fname = ['tracks_' num2str(kexp) '.mat'];
    data = load([fpathT_tracks fname]).(vname); % particle's trajectory struct
    
    for kfield = 1:nfields
        NNx_temp= arrayfun(@(X)(hist(X.(fields(kfield,:)),Xx.(fields(kfield,:)))),data,'UniformOutput',false);
        NNx.(fields(kfield,:)) = [NNx.(fields(kfield,:)),NNx_temp];  
        clear NNx_temp
    end
end
for kfield = 1:nfields
    Nx.(fields(kfield,:)) = sum(cell2mat(NNx.(fields(kfield,:))'),1);
end

for kfield = 1:nfields
    pdf(kfield).N=horzcat(L.(fields(kfield,:)));
    pdf(kfield).pdf=Nx.(fields(kfield,:))/integ(Nx.(fields(kfield,:)),Xx.(fields(kfield,:)));
    pdf(kfield).xpdf=Xx.(fields(kfield,:));
    pdf(kfield).meanb=moy.(fields(kfield,:));
    pdf(kfield).mean=integ(pdf(kfield).xpdf.*pdf(kfield).pdf,pdf(kfield).xpdf);
    pdf(kfield).std=sqrt(integ((pdf(kfield).xpdf-pdf(kfield).mean).^2.*pdf(kfield).pdf,pdf(kfield).xpdf));
    pdf(kfield).stdb=sigma.(fields(kfield,:));
    pdf(kfield).skewness=integ((pdf(kfield).xpdf-pdf(kfield).mean).^3.*pdf(kfield).pdf,pdf(kfield).xpdf)/pdf(kfield).std^3;
    %pdf(kfield).skewnessb=skewness(x);
    pdf(kfield).flatness=integ((pdf(kfield).xpdf-pdf(kfield).mean).^4.*pdf(kfield).pdf,pdf(kfield).xpdf)/pdf(kfield).std^4;
    %pdf(kfield).flatnessb=kurtosis(x);
end


Nx=emptyStruct;
for kfield = 1:nfields
    Xx.(fields(kfield,:))=linspace(-w,w,n);
end

NNx = emptyStruct;
for kexp = 1:Nexp
    fname = ['tracks_' num2str(kexp) '.mat'];
    data = load([fpathT_tracks fname]).(vname); % particle's trajectory struct
    
    for kfield = 1:nfields
        NNx_temp = arrayfun(@(X)(hist((X.(fields(kfield,:))-moy.(fields(kfield,:)))/sigma.(fields(kfield,:)),Xx.(fields(kfield,:)))),data,'UniformOutput',false);
        NNx.(fields(kfield,:)) = [NNx.(fields(kfield,:)),NNx_temp];  
        clear NNx_temp
    end
end

for kfield = 1:nfields
    Nx.(fields(kfield,:)) = sum(cell2mat(NNx.(fields(kfield,:))'),1);
end

for kfield = 1:nfields
    pdf(kfield).pdfn=Nx.(fields(kfield,:))/integ(Nx.(fields(kfield,:)),Xx.(fields(kfield,:)));
    pdf(kfield).xpdfn=Xx.(fields(kfield,:));
end

