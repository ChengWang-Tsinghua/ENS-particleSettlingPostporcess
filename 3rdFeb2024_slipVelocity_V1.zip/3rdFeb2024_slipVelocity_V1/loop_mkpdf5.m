clear;clc
tic
fpathT = ['.' filesep 'tracers' filesep];
fpathP = ['.' filesep 'particle' filesep];

fpathT_tracks = ['.' filesep 'tracers' filesep 'Tracks' filesep];
fpathP_tracks = ['.' filesep 'particle' filesep 'Tracks' filesep];

Nexp = 100;
vname = 'tracklong_tracers';
field  = 'Vx';
n = 256;
w=10;

L = [];
sum_moy = [];
for kexp = 1:Nexp
    fname = ['tracks_' num2str(kexp) '.mat'];
    data = load([fpathT_tracks fname]).(vname); % particle's trajectory struct

    L_kexp=arrayfun(@(X)(numel(X.(field))),data);
    sum_moy_kexp=sum(arrayfun(@(X)(mean(X.(field))),data).*L_kexp);
    L = [L,L_kexp];
    sum_moy = [sum_moy,sum_moy_kexp];
    clear data
end
moy = sum(sum_moy)/sum(L);

L = [];
sum_sigma2 = [];
for kexp = 1:Nexp
    fname = ['tracks_' num2str(kexp) '.mat'];
    data = load([fpathT_tracks fname]).(vname); % particle's trajectory struct
    
    L_kexp=arrayfun(@(X)(numel(X.(field))),data);
    sum_sigma2_kexp=sum(arrayfun(@(X)(mean((X.(field)-moy).^2)),data).*L_kexp);
    L = [L,L_kexp];
    sum_sigma2 = [sum_sigma2,sum_sigma2_kexp];
    clear tracklong_tracerss
end
sigma = sqrt(sum(sum_sigma2)/sum(L));

mm = moy -w*sigma;
MM = moy +w*sigma;

Xx=linspace(mm,MM,n);
Nx=zeros(1,n);

NNx = [];
for kexp = 1:Nexp
    fname = ['tracks_' num2str(kexp) '.mat'];
    data = load([fpathT_tracks fname]).(vname); % particle's trajectory struct
    
    NNx_temp=arrayfun(@(X)(hist(X.(field),Xx)),data,'UniformOutput',false);
    NNx = [NNx,NNx_temp];
    clear NNx_temp
end
Nx=sum(cell2mat(NNx'),1);


pdf.N=L;
pdf.pdf=Nx/integ(Nx,Xx);
pdf.xpdf=Xx;
pdf.meanb=moy;
pdf.mean=integ(pdf.xpdf.*pdf.pdf,pdf.xpdf);
pdf.std=sqrt(integ((pdf.xpdf-pdf.mean).^2.*pdf.pdf,pdf.xpdf));
pdf.stdb=sigma;
pdf.skewness=integ((pdf.xpdf-pdf.mean).^3.*pdf.pdf,pdf.xpdf)/pdf.std^3;
%pdf.skewnessb=skewness(x);
pdf.flatness=integ((pdf.xpdf-pdf.mean).^4.*pdf.pdf,pdf.xpdf)/pdf.std^4;
%pdf.flatnessb=kurtosis(x);

Nx=zeros(1,n);
Xx=linspace(-w,w,n);


NNx = [];
for kexp = 1:Nexp
    fname = ['tracks_' num2str(kexp) '.mat'];
    data = load([fpathT_tracks fname]).(vname); % particle's trajectory struct
    
    NNx_temp=arrayfun(@(X)(hist((X.(field)-moy)/sigma,Xx)),data,'UniformOutput',false);
    NNx = [NNx,NNx_temp];
    clear NNx_temp
end
Nx=sum(cell2mat(NNx'),1);


pdf.pdfn=Nx/integ(Nx,Xx);
pdf.xpdfn=Xx;
toc