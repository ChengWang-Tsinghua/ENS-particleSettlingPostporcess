function plotLagr_pdfs(pdfV,pdfA,fout_lagr,color3)

%% Tracer: plot PDFs
figure;
semilogy(pdfV(1).xpdfn,pdfV(1).pdfn,'d-',Color=color3(1,:));hold on;
semilogy(pdfV(2).xpdfn,pdfV(2).pdfn,'d-',Color=color3(2,:));
semilogy(pdfV(3).xpdfn,pdfV(3).pdfn,'d-',Color=color3(3,:));
semilogy(pdfA(1).xpdfn,pdfA(1).pdfn,'o-',Color=color3(1,:));
semilogy(pdfA(2).xpdfn,pdfA(2).pdfn,'o-',Color=color3(2,:));
semilogy(pdfA(3).xpdfn,pdfA(3).pdfn,'o-',Color=color3(3,:));

xpdf=linspace(-5,5,1024);
plot(xpdf,normpdf(xpdf,0,1),'k');

legend('$u_x$','$u_y$','$u_z$','$a_x$','$a_y$','$a_z$');
% title('$PDF$')
ylabel('$PDF$')
xlabel('$u, a$')
grid on
axis padded

% add subfigure
%
% axes('Position',[0.22 0.62 0.22 0.22]);
% semilogy(pdfV(1).xpdfn,pdfV(1).pdfn,'d-',MarkerSize=2,Color=color3(1,:));hold on;
% semilogy(pdfV(2).xpdfn,pdfV(2).pdfn,'d-',MarkerSize=2,Color=color3(2,:));
% semilogy(pdfV(3).xpdfn,pdfV(3).pdfn,'d-',MarkerSize=2,Color=color3(3,:));
% 
% semilogy(pdfA(1).xpdfn,pdfA(1).pdfn,'^-',MarkerSize=2,Color=color3(1,:));
% semilogy(pdfA(2).xpdfn,pdfA(2).pdfn,'^-',MarkerSize=2,Color=color3(2,:));
% semilogy(pdfA(3).xpdfn,pdfA(3).pdfn,'^-',MarkerSize=2,Color=color3(3,:));
% 
% xpdf=linspace(-5,5,1024);
% plot(xpdf,normpdf(xpdf,0,1),'k');
% grid on
% set(gca,FontSize=12)
% xlim([-5 5])

clear xpdf

savefig_custom(fout_lagr,'PDFs',8,7)