function plotLagr_Corr(Ruu,Raa,Fs,fout_lagr,color3)

%% Tracer: plot Correlation function (fit)
% figure;
% main plot: zoom in
f1 = figure;
tiledlayout(2,1)
nexttile
plot(Ruu(1).tau/Fs,Ruu(1).mean/Ruu(1).mean(1),'d',Color=color3(1,:),MarkerSize=1);hold on
plot(Ruu(2).tau/Fs,Ruu(2).mean/Ruu(2).mean(1),'d',Color=color3(2,:),MarkerSize=1);
plot(Ruu(3).tau/Fs,Ruu(3).mean/Ruu(3).mean(1),'d',Color=color3(3,:),MarkerSize=1);
% plot(Ruufit(1).x,Ruufit(1).yfit,'-',Color=color3(1,:));hold on
% plot(Ruufit(2).x,Ruufit(2).yfit,'-',Color=color3(2,:))
% plot(Ruufit(3).x,Ruufit(3).yfit,'-',Color=color3(3,:))

legend('$x$','$y$','$z$',Location='northwest')
% title('$R_{uu}$')
% ylabel('$\frac{\langle u(t)u(t+\tau) \rangle} {\langle u^2(t) \rangle}$');
ylabel('$R_{uu}$');
xlabel('$t [s]$')
grid on
axis tight

nexttile
plot(Raa(1).tau/Fs,Raa(1).mean/Raa(1).mean(1),'o',Color=color3(1,:),MarkerSize=1);hold on
plot(Raa(2).tau/Fs,Raa(2).mean/Raa(2).mean(1),'o',Color=color3(2,:),MarkerSize=1);
plot(Raa(3).tau/Fs,Raa(3).mean/Raa(3).mean(1),'o',Color=color3(3,:),MarkerSize=1);
% plot(Raafit(1).x,Raafit(1).yfit,'-',Color=color3(1,:))
% plot(Raafit(2).x,Raafit(2).yfit,'-',Color=color3(2,:))
% plot(Raafit(3).x,Raafit(3).yfit,'-',Color=color3(3,:))

legend('$x$','$y$','$z$',Location='southwest')
% title('$R_{aa}$')
% ylabel('$\frac{\langle a(t)a(t+\tau) \rangle} {\langle a^2(t) \rangle}$');
ylabel('$R_{aa}$');
xlabel('$t [s]$')
grid on
axis tight

% add inset: zoom out 
% axes('Position',[0.4 0.3 0.3 0.2]);
% plot(Ruu(1).tau/Fs,Ruu(1).mean/Ruu(1).mean(1),'d',Color=color3(1,:));hold on
% plot(Ruu(2).tau/Fs,Ruu(2).mean/Ruu(2).mean(1),'d',Color=color3(2,:));
% plot(Ruu(3).tau/Fs,Ruu(3).mean/Ruu(3).mean(1),'d',Color=color3(3,:));
% 
% plot(Raa(1).tau/Fs,Raa(1).mean/Raa(1).mean(1),'^',Color=color3(1,:));
% plot(Raa(2).tau/Fs,Raa(2).mean/Raa(2).mean(1),'^',Color=color3(2,:));
% plot(Raa(3).tau/Fs,Raa(3).mean/Raa(3).mean(1),'^',Color=color3(3,:));
% 
% plot(Ruufit(1).x,Ruufit(1).yfit,'-',Color=color3(1,:),);hold on
% plot(Ruufit(2).x,Ruufit(2).yfit,'-',Color=color3(2,:))
% plot(Ruufit(3).x,Ruufit(3).yfit,'-',Color=color3(3,:))
% 
% plot(Raafit(1).x,Raafit(1).yfit,'-',Color=color3(1,:))
% plot(Raafit(2).x,Raafit(2).yfit,'-',Color=color3(2,:))
% plot(Raafit(3).x,Raafit(3).yfit,'-',Color=color3(3,:))
% set(gca,FontSize=12)
% grid on
% axis tight

savefig_custom(fout_lagr,'Corr',8,7)
