function plotLagr_S2L(S2L,Fs,fout_lagr,color3)

%% Tracer: Lagrangian plot: S2L
figure;
loglog(S2L(1).tau/Fs,S2L(1).mean,'d-',Color=color3(1,:));hold on
loglog(S2L(2).tau/Fs,S2L(2).mean,'d-',Color=color3(2,:));
loglog(S2L(3).tau/Fs,S2L(3).mean,'d-',Color=color3(3,:));

xS2L = linspace(1,8,100)/Fs;
loglog(xS2L,9e8*xS2L.^2,'k--')

xS2L = linspace(8,200,100)/Fs;
loglog(xS2L,2.5e6*xS2L.^1,'k--')

legend('x','y','z')
% title('$S_2^L$')
ylabel('$S_2^L [mm^2/s^2]$')
xlabel('$t [s]$')
text(6e-4,8e2,'$\tau^2$',FontSize=18,FontWeight='bold')
text(7e-3,4e4,'$\tau$',FontSize=18,FontWeight='bold')
grid on
axis padded

clear xS2L

savefig_custom(fout_lagr,'S2L',8,7)
