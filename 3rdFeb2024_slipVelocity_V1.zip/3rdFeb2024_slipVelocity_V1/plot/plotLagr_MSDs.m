function plotLagr_MSDs(MSD,Fs,fout_lagr,color3)

%% Tracer: plot MSD
figure;
loglog(MSD(1).tau/Fs,MSD(1).mean,'d-',Color=color3(1,:));hold on
loglog(MSD(2).tau/Fs,MSD(2).mean,'d-',Color=color3(2,:));
loglog(MSD(3).tau/Fs,MSD(3).mean,'d-',Color=color3(3,:));

xMSD = linspace(1,max(MSD(1).tau),1000)/Fs;
loglog(xMSD,2e5*xMSD.^2,'--',Color=color1)

legend('x','y','z')
% title('$MSD$')
ylabel('$\sigma^2_{MSD} [mm^2]$')
xlabel('$t [s]$')
text(1e-2,6e1,'$\tau^2$','FontSize',18,FontWeight='bold')
grid on
axis padded

clear xMSD

savefig_custom(fout_lagr,'MSDs',8,7)