function plotLagr_dtCorr(Ruu,Raa,Fs,fout_lagr,color3)

%% Tracer: plot Correlation function -- dt method (denosied) 
fields = fieldnames(tau);
figure
tiledlayout(2,1,'TileSpacing','tight');
nexttile;
for kfield = 1:numel(fields)
    f = fields{kfield};
    plot(tau.(f),corrv.(f)/corrv.(f)(1),'-',Color=color3(kfield,:),LineWidth = 2);hold on
end
legend('$x$','$y$','$z$',Location='southwest')
ylabel('$R_{uu}$');
xlabel('$t [s]$')
% ylabel('$\frac{\langle u(t)u(t+\tau) \rangle} {\langle u^2(t) \rangle}$');
grid;

nexttile;
for kfield = 1:numel(fields)
    f = fields{kfield};
    plot(tau.(f),corra.(f)/corra.(f)(1),'-',Color=color3(kfield,:),LineWidth = 2);hold on
end
grid;
legend('$x$','$y$','$z$',Location='southwest')
% ylabel('$\frac{\langle a(t)a(t+\tau) \rangle} {\langle a^2(t) \rangle}$');
ylabel('$R_{aa}$');
xlabel('$t [s]$')
savefig_custom(fout_lagr,'dtCorr',8,7)