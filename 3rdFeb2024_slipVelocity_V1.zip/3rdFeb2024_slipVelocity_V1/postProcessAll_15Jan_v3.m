clear all;clc;close all

%% outlines:
% 0). put this file at the above folder of 'tracers' and 'particle'
% 1). first process the tracers's data, which will give the mean velocity 
% field <u> and the rms of the velocity field <u^2>^0.5 as well as 
% turbulence quantities like the dissipation rate (epsilon) and 
% fluctuation of the fluid velocity (sigmau).
% 2). then process the big particle's data 
% 3). at the end we analysis both to to have the dimensionless parameters 
% like Re_lambda) and to see their interactions (slip velocity)

%% settings for plots

Fs = 2996;
Nexp = 100;

addpath(genpath('C:\Users\ChengWang\Desktop\SDT_EXP'));
mycolormap = mycolor('#063970','#e28743');%('#063970','#eeeee4','#e28743')
color1 = '#000000';
color3 = [mycolormap(1,:);mycolormap((size(mycolormap,1)+1)/2,:);mycolormap(end,:)];
color5 = [mycolormap(1,:);mycolormap(round((size(mycolormap,1)+1)/4),:);mycolormap(round(2*(size(mycolormap,1)+1)/4),:);mycolormap(round(3*(size(mycolormap,1)+1)/4),:);mycolormap(end,:)];

set(groot, 'defaultAxesTickLabelInterpreter','latex'); 
set(groot, 'defaultTextInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');
set(groot, 'defaultLegendLocation','best');
set(groot, 'defaultAxesTitleFontWeight','bold')
set(groot,'defaultLegendAutoUpdate','off')

set(groot, 'defaultLineLineWidth',2)
set(groot,'defaultLineMarkerSize',8)
set(groot, 'defaultAxesFontSize',18)
set(groot, 'defaultLegendFontSize',12)
set(groot, 'defaultTextFontSize',15)

%% Tracer: output path
fpathT = [pwd filesep 'tracers' filesep];
fpathT_STB = [fpathT 'Seperate_Files_STB' filesep];

figLagr = [fpathT 'Figures_Lagr' filesep];
figEuler = [fpathT 'Figures_Euler' filesep];
figEulerSubsMean = [fpathT 'Figures_EulerSubsMean' filesep];
fmatTracks = [fpathT 'Tracks' filesep];
fmatLagrStats = [fpathT 'LagrangianStats' filesep];
fmatEulerStats = [fpathT 'EulerStats' filesep];
fmatEulerStats_subsMean = [fpathT 'EulerStats_subsMean' filesep];
fmattracks_subsMean = [fpathT 'Tracks_subsMean' filesep];

mkdir(figLagr)
mkdir(figEuler)
mkdir(figEulerSubsMean)
mkdir(fmatTracks)
mkdir(fmatLagrStats)
mkdir(fmatEulerStats)
mkdir(fmatEulerStats_subsMean)
mkdir(fmattracks_subsMean)

%% Tracer: find the longest video
% the measurement of the turbulence will be based on the longest video 
% (T~100 times Kolmogorov time scale)
% as using all the recorded videos to compute the Lagrangian& Eulerian fields is not feasible 
Nframemax = 1e6;
tmax = 0;

for i = 1:Nexp
    fnamein = ['STB_' num2str(i) '.mat'];
    
    load([fpathT_STB fnamein]);
    t = mod(max(part.T),Nframemax);
    if t>tmax
        idx_maxT = i;
        tmax = t;
    end
    clear part
end
fprintf('longest video idx: %d\n frames = %d\n',idx_maxT,tmax)
clear tmax t

%% Tracer: find proper filter width
ifParticle = 0;
frame0 = 0;
long_thres = 5;
[track,Ilong] = buildTracks(fpathT_STB,['STB_' num2str(idx_maxT) '.mat'],ifParticle,frame0,long_thres);
[s,m,w] = findOptimalFilterWidth(track,Ilong);

%% Tracer: set values for gaussian filter
wopt = 6;
lopt = 20;

%% Tracer: plot std
plot([wopt wopt],ylim,'k--')
savefig_custom(figLagr,'Std',8,7)

%% Tracer: save to tracks, iteration over each experiments
% ifParticle = 0;
% frame0 = 0;
% long_thres = 10;
for i = 1:Nexp
    fnamein = ['STB_' num2str(i) '.mat'];
    [track,Ilong] = buildTracks(fpathT_STB,fnamein,ifParticle,frame0,long_thres);
    
    % Particle: Estimate smoothed tracks with optimal filter width
    tracklong_tracers=calcVelLEM(track(Ilong),wopt,lopt,Fs);
    Ine=arrayfun(@(X)(~isempty(X.Vx)),tracklong_tracers)==1;
    tracklong_tracers = tracklong_tracers(Ine);

    fnameout1 = ['tracks_' num2str(i) '.mat'];
    save([fmatTracks filesep fnameout1],'long_thres','tracklong_tracers','wopt','lopt','Fs')
    
    fnameout2 = ['LagrangianStats_' num2str(i) '.mat'];
    save([fmatLagrStats filesep fnameout2],'s','w','wopt','lopt')
    
    clear track Ilong Ine
end

%% Tracer: load the tracks of the longest videos
load([fmatTracks filesep 'tracks_' num2str(idx_maxT) '.mat'])
fprintf('loaded video tracks: %d\n',idx_maxT)

%% Tracer: find optimal ndt for Correlation function -- dt method
nmaxdt = 10;
nmaxtau = 10;
find_optimal_ndt(tracklong_tracers,nmaxdt,nmaxtau,'X','save')
find_optimal_ndt(tracklong_tracers,nmaxdt,nmaxtau,'Y','save')
find_optimal_ndt(tracklong_tracers,nmaxdt,nmaxtau,'Z','save')
clear nmaxtau nmaxtau

%% Tracers: iteration over each experiments

pdf.Nbins = 256;
pdf.n = 10;
ndt.start = [8 8 8];
ndt.len = [10 10 10];

dt = [6 8 10 12];
nbins = [20 21 22];
threshold = 5;
gridRange.x = [-20 20];
gridRange.y = [-40 40];
gridRange.z = [-20 20];


for kexp = 1:Nexp
    fprintf('video starts: %d\n',kexp)
    
    LagragianStat(fmatTracks,Fs,pdf,ndt,fmatLagrStats,kexp) % lagrangian stats

    twoPointsEulerianStats_Mica_Speedup2(fmatTracks,[0.5 80],100,fmatEulerStats,kexp); % raw field
    
    meanEulerianFields(fmatTracks,Fs,dt,nbins,threshold,gridRange,fmatEulerStats,fmattracks_subsMean,kexp) % meanFields

    twoPointsEulerianStats_Mica_Speedup2(fmattracks_subsMean,[0.5 80],100,fmatEulerStats_subsMean,kexp); % rms field
    
    fprintf('video processed: %d\n',kexp)
end

%% Tracer: lagStats over all videos
for kexp = 1:Nexp
    load([fmatLagrStats filesep 'LagrangianStats_' num2str(kexp) '.mat'],'LagrangianStats'); 
    
    if kexp == 1
        fieldname = fieldnames(LagrangianStats);
        for i = 1:numel(fieldname)
            lagStats.(fieldname{i}) = LagrangianStats.(fieldname{i});  
        end
    else
        for i = 1:numel(fieldname)
            lagStats.(fieldname{i})=[lagStats.(fieldname{i});LagrangianStats.(fieldname{i})];
        end
    end
    clear LagrangianStats
end

[averLagStats,LagStats] = averLagrangianStats(lagStats);
save([figLagr 'lagStats.mat'],'averLagStats','LagStats')

%% Tracer: plot PDFs
figure;
semilogy(averLagStats.xpdfnVx,averLagStats.pdfnVx,'d-',Color=color3(1,:));hold on;
semilogy(averLagStats.xpdfnVy,averLagStats.pdfnVy,'d-',Color=color3(2,:));hold on;
semilogy(averLagStats.xpdfnVz,averLagStats.pdfnVz,'d-',Color=color3(3,:));hold on;
semilogy(averLagStats.xpdfnAx,averLagStats.pdfnAx,'o-',Color=color3(1,:));hold on;
semilogy(averLagStats.xpdfnAy,averLagStats.pdfnAy,'o-',Color=color3(2,:));hold on;
semilogy(averLagStats.xpdfnAz,averLagStats.pdfnAz,'o-',Color=color3(3,:));hold on;

xpdf=linspace(-5,5,1024);
plot(xpdf,normpdf(xpdf,0,1),Color=color1);

legend('$u_x$','$u_y$','$u_z$','$a_x$','$a_y$','$a_z$');
% title('$PDF$')
ylabel('$PDF$')
xlabel('$u, a$')
grid on
axis padded
clear xpdf
savefig_custom(figLagr,'PDFs',16,6)

%% Tracer: plot MSD
figure;
loglog(averLagStats.tauMSDx/Fs,averLagStats.meanMSDx,'d-',Color=color3(1,:));hold on;
loglog(averLagStats.tauMSDy/Fs,averLagStats.meanMSDy,'d-',Color=color3(2,:));hold on;
loglog(averLagStats.tauMSDz/Fs,averLagStats.meanMSDz,'d-',Color=color3(3,:));hold on;

xMSD = linspace(1,max(averLagStats.tauMSDx),1000)/Fs;
loglog(xMSD,2e5*xMSD.^2,'--',Color=color1)

legend('x','y','z')
ylabel('$\sigma^2_{MSD} [mm^2]$')
xlabel('$t [s]$')
text(1e-2,6e1,'$\tau^2$','FontSize',18,FontWeight='bold')
grid on
axis padded
clear xMSD
savefig_custom(figLagr,'MSDs',8,7)

%% Tracer: plot S2L
figure;
loglog(averLagStats.tauS2Lx/Fs,averLagStats.meanS2Lx,'d-',Color=color3(1,:));hold on;
loglog(averLagStats.tauS2Ly/Fs,averLagStats.meanS2Ly,'d-',Color=color3(2,:));hold on;
loglog(averLagStats.tauS2Lz/Fs,averLagStats.meanS2Lz,'d-',Color=color3(3,:));hold on;

xS2L = linspace(1,8,100)/Fs;
loglog(xS2L,9e8*xS2L.^2,'--',Color=color1)

xS2L = linspace(10,200,100)/Fs;
loglog(xS2L,2.5e6*xS2L.^1,'--',Color=color1)

legend('x','y','z')
ylabel('$S_2^L [mm^2/s^2]$')
xlabel('$t [s]$')
text(6e-4,8e2,'$\tau^2$',FontSize=18,FontWeight='bold')
text(7e-3,4e4,'$\tau$',FontSize=18,FontWeight='bold')
grid on
axis padded
clear xS2L
savefig_custom(figLagr,'S2L',8,7)

%% Tracer: plot Correlation function (fit)

% !!!! key params to make the fits better !!!!
% in correlationFit2.m, startpoints, lowerpoints, upperpoints are crucial!!
nCorrFitV = [200 200 200];
nCorrFitAstart = [1 1 1];
nCorrFitAend = [65 65 60];
if2layersV = 1;
if2layersA = 1;
ifboundedV = [1 1 1]; 
ifboundedA = [1 1 1];

Ruufitx = correlationFit2(averLagStats.tauRuux/Fs,averLagStats.meanRuux,1,nCorrFitV(1),'V',if2layersV,ifboundedV(1));
Ruufity = correlationFit2(averLagStats.tauRuuy/Fs,averLagStats.meanRuuy,1,nCorrFitV(2),'V',if2layersV,ifboundedV(2));
Ruufitz = correlationFit2(averLagStats.tauRuuz/Fs,averLagStats.meanRuuz,1,nCorrFitV(3),'V',if2layersV,ifboundedV(3));
Raafitx = correlationFit2(averLagStats.tauRaax/Fs,averLagStats.meanRaax,nCorrFitAstart(1),nCorrFitAend(1),'A',if2layersA,ifboundedA(1));
Raafity = correlationFit2(averLagStats.tauRaay/Fs,averLagStats.meanRaay,nCorrFitAstart(2),nCorrFitAend(2),'A',if2layersA,ifboundedA(2));
Raafitz = correlationFit2(averLagStats.tauRaaz/Fs,averLagStats.meanRaaz,nCorrFitAstart(3),nCorrFitAend(3),'A',if2layersA,ifboundedA(3));
clear nCorrFitV nCorrFitA if2layersV  if2layersA ifboundedV ifboundedA

ylimV = [-0.5 1];
ylimA = [-0.15 1];

figure;
tiledlayout(3,2,"TileSpacing","loose")

nexttile % ux
plot(averLagStats.tauRuux/Fs,averLagStats.meanRuux/averLagStats.meanRuux(1),'d',Color=color3(1,:),MarkerSize=2);hold on
plot(Ruufitx.x,Ruufitx.yfit,'-',Color=color3(1,:));hold on
legend('$R_{uu}$','$R^{fit}_{uu}$',Location='northeast')
ylabel('$R^x_{uu}[m^2/s^2]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimV)
patch_x = [Ruufitx.x, fliplr(Ruufitx.x)];
patch_y = [Ruufitx.yfit', zeros(size(Ruufitx.yfit'))];
patch(patch_x, patch_y, color3(1,:), 'FaceAlpha', 0.3);
lagTimeX = trapz(patch_x, patch_y);


nexttile % ax
plot(averLagStats.tauRaax/Fs,averLagStats.meanRaax/averLagStats.meanRaax(1),'o',Color=color3(1,:),MarkerSize=2);hold on
plot(Raafitx.x,Raafitx.yfit,'-',Color=color3(1,:));hold on
legend('$R_{aa}$','$R^{fit}_{aa}$',Location='northwest')
ylabel('$R^x_{aa}[m^2/s^4]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimA)
patch_x = [Raafitx.x, fliplr(Raafitx.x)];
patch_y = [Raafitx.yfit', zeros(size(Raafitx.yfit'))];
patch(patch_x, max(patch_y, 0), color3(1,:), 'FaceAlpha', 0.3);
dissLagTimeX = trapz(patch_x, max(patch_y, 0));


nexttile % uy
plot(averLagStats.tauRuuy/Fs,averLagStats.meanRuuy/averLagStats.meanRuuy(1),'d',Color=color3(2,:),MarkerSize=2);hold on
plot(Ruufity.x,Ruufity.yfit,'-',Color=color3(2,:));hold on
ylabel('$R^y_{uu}[m^2/s^2]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimV)
patch_x = [Ruufity.x, fliplr(Ruufity.x)];
patch_y = [Ruufity.yfit', zeros(size(Ruufity.yfit'))];
patch(patch_x, patch_y, color3(2,:), 'FaceAlpha', 0.3);
lagTimeY = trapz(patch_x, patch_y);

nexttile % ay
plot(averLagStats.tauRaay/Fs,averLagStats.meanRaay/averLagStats.meanRaaz(1),'o',Color=color3(2,:),MarkerSize=2);hold on
plot(Raafity.x,Raafity.yfit,'-',Color=color3(2,:));hold on
ylabel('$R^y_{aa}[m^2/s^4]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimA)
patch_x = [Raafity.x, fliplr(Raafity.x)];
patch_y = [Raafity.yfit', zeros(size(Raafity.yfit'))];
patch(patch_x, max(patch_y, 0), color3(2,:), 'FaceAlpha', 0.3);
dissLagTimeY = trapz(patch_x, max(patch_y, 0));

nexttile % uz
plot(averLagStats.tauRuuz/Fs,averLagStats.meanRuuz/averLagStats.meanRuuz(1),'d',Color=color3(3,:),MarkerSize=2);hold on
plot(Ruufitz.x,Ruufitz.yfit,'-',Color=color3(3,:));hold on
ylabel('$R^z_{uu}[m^2/s^2]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimV)
patch_x = [Ruufitz.x, fliplr(Ruufitz.x)];
patch_y = [Ruufitz.yfit', zeros(size(Ruufitz.yfit'))];
patch(patch_x, patch_y, color3(3,:), 'FaceAlpha', 0.3);
lagTimeZ = trapz(patch_x, patch_y);

nexttile % az
plot(averLagStats.tauRaaz/Fs,averLagStats.meanRaaz/averLagStats.meanRaaz(1),'o',Color=color3(3,:),MarkerSize=2);hold on
plot(Raafitz.x,Raafitz.yfit,'-',Color=color3(3,:));hold on
ylabel('$R^z_{aa}[m^2/s^4]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimA)
patch_x = [Raafitz.x, fliplr(Raafitz.x)];
patch_y = [Raafitz.yfit', zeros(size(Raafitz.yfit'))];
patch(patch_x, max(patch_y, 0), color3(3,:), 'FaceAlpha', 0.3);
dissLagTimeZ = trapz(patch_x, max(patch_y, 0));

savefig_custom(figLagr,'Corr',16,10)
save([figLagr 'timescale.mat'],'lagTimeX','lagTimeY','lagTimeZ','dissLagTimeX','dissLagTimeY','dissLagTimeZ')

%% Tracer: plot Correlation function -- dt method (denosied) 

nCorrFitV = [200 200 200];
nCorrFitAstart = [15 15 10];
nCorrFitAend = [65 65 60];
if2layersV = 1;
if2layersA = 0;
ifboundedV = [1 1 1]; 
ifboundedA = [1 1 1];

dtRuufitx = correlationFit2(averLagStats.taudtCorrvx,averLagStats.corrdtCorrvx,1,nCorrFitV(1),'V',if2layersV,ifboundedV(1));
dtRuufity = correlationFit2(averLagStats.taudtCorrvy,averLagStats.corrdtCorrvy,1,nCorrFitV(2),'V',if2layersV,ifboundedV(2));
dtRuufitz = correlationFit2(averLagStats.taudtCorrvz,averLagStats.corrdtCorrvz,1,nCorrFitV(3),'V',if2layersV,ifboundedV(3));
dtRaafitx = correlationFit2(averLagStats.taudtCorrax,averLagStats.corrdtCorrax,nCorrFitAstart(1),nCorrFitAend(1),'A',if2layersA,ifboundedA(1));
dtRaafity = correlationFit2(averLagStats.taudtCorray,averLagStats.corrdtCorray,nCorrFitAstart(2),nCorrFitAend(2),'A',if2layersA,ifboundedA(2));
dtRaafitz = correlationFit2(averLagStats.taudtCorraz,averLagStats.corrdtCorraz,nCorrFitAstart(3),nCorrFitAend(3),'A',if2layersA,ifboundedA(3));
clear nCorrFitV nCorrFitA if2layersV  if2layersA ifboundedV ifboundedA

ylimV = [-0.5 1];
ylimA = [-0.15 1];

figure;
tiledlayout(3,2,"TileSpacing","loose")

nexttile % ux
plot(averLagStats.taudtCorrvx,averLagStats.corrdtCorrvx/averLagStats.corrdtCorrvx(1),'d',Color=color3(1,:),MarkerSize=2);hold on
plot(dtRuufitx.x,dtRuufitx.yfit,'-',Color=color3(1,:));hold on
legend('$R_{uu}$','$R^{fit}_{uu}$',Location='northeast')
ylabel('$R^x_{uu}[m^2/s^2]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimV)
patch_x = [dtRuufitx.x, fliplr(dtRuufitx.x)];
patch_y = [dtRuufitx.yfit', zeros(size(dtRuufitx.yfit'))];
patch(patch_x, patch_y, color3(1,:), 'FaceAlpha', 0.3);
lagTimeX = trapz(patch_x, patch_y);


nexttile % ax
plot(averLagStats.taudtCorrax,averLagStats.corrdtCorrax/averLagStats.corrdtCorrax(1),'o',Color=color3(1,:),MarkerSize=2);hold on
plot(dtRaafitx.x,dtRaafitx.yfit,'-',Color=color3(1,:));hold on
legend('$R_{aa}$','$R^{fit}_{aa}$',Location='northeast')
ylabel('$R^x_{aa}[m^2/s^4]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimA)
patch_x = [dtRaafitx.x, fliplr(dtRaafitx.x)];
patch_y = [dtRaafitx.yfit', zeros(size(dtRaafitx.yfit'))];
patch(patch_x, max(patch_y, 0), color3(3,:), 'FaceAlpha', 0.3);
dissLagTimeX = trapz(patch_x, max(patch_y, 0));


nexttile % uy
plot(averLagStats.taudtCorrvy,averLagStats.corrdtCorrvy/averLagStats.corrdtCorrvy(1),'d',Color=color3(2,:),MarkerSize=2);hold on
plot(dtRuufity.x,dtRuufity.yfit,'-',Color=color3(2,:));hold on
ylabel('$R^y_{uu}[m^2/s^2]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimV)
patch_x = [dtRuufity.x, fliplr(dtRuufity.x)];
patch_y = [dtRuufity.yfit', zeros(size(dtRuufity.yfit'))];
patch(patch_x, patch_y, color3(2,:), 'FaceAlpha', 0.3);
lagTimeY = trapz(patch_x, patch_y);

nexttile % ay
plot(averLagStats.taudtCorray,averLagStats.corrdtCorray/averLagStats.corrdtCorray(1),'o',Color=color3(2,:),MarkerSize=2);hold on
plot(dtRaafity.x,dtRaafity.yfit,'-',Color=color3(2,:));hold on
ylabel('$R^y_{aa}[m^2/s^4]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimA)
patch_x = [dtRaafity.x, fliplr(dtRaafity.x)];
patch_y = [dtRaafity.yfit', zeros(size(dtRaafity.yfit'))];
patch(patch_x, max(patch_y, 0), color3(3,:), 'FaceAlpha', 0.3);
dissLagTimeY = trapz(patch_x, max(patch_y, 0));


nexttile % uz
plot(averLagStats.taudtCorrvz,averLagStats.corrdtCorrvz/averLagStats.corrdtCorrvz(1),'d',Color=color3(3,:),MarkerSize=2);hold on
plot(dtRuufitz.x,dtRuufitz.yfit,'-',Color=color3(3,:));hold on
ylabel('$R^z_{uu}[m^2/s^2]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimV)
patch_x = [dtRuufitz.x, fliplr(dtRuufitz.x)];
patch_y = [dtRuufitz.yfit', zeros(size(dtRuufitz.yfit'))];
patch(patch_x, patch_y, color3(3,:), 'FaceAlpha', 0.3);
lagTimeZ = trapz(patch_x, patch_y);


nexttile % az
plot(averLagStats.taudtCorraz,averLagStats.corrdtCorraz/averLagStats.corrdtCorraz(1),'o',Color=color3(3,:),MarkerSize=2);hold on
plot(dtRaafitz.x,dtRaafitz.yfit,'-',Color=color3(3,:));hold on
ylabel('$R^z_{aa}[m^2/s^4]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimA)
patch_x = [dtRaafitz.x, fliplr(dtRaafitz.x)];
patch_y = [dtRaafitz.yfit', zeros(size(dtRaafitz.yfit'))];
patch(patch_x, max(patch_y, 0), color3(3,:), 'FaceAlpha', 0.3);
dissLagTimeZ = trapz(patch_x, max(patch_y, 0));


savefig_custom(figLagr,'dtCorr',16,10)
save([figLagr 'timescale_dt.mat'],'lagTimeX','lagTimeY','lagTimeZ','dissLagTimeX','dissLagTimeY','dissLagTimeZ')


%% Tracer: eulerStats over all videos
for kexp = 1:Nexp
    load([fmatEulerStats filesep 'EulerianStats_' num2str(kexp) '.mat']); 
    if kexp == 1
        fieldname1 = fieldnames(eulerStats);
        for i = 1:numel(fieldname1)
            EulerStats.(fieldname1{i}) = eulerStats.(fieldname1{i});  
        end
        averGridsA = gridsA;
        averGridsArms= gridsArms;
        averGridsV = gridsV;
        averGridsVrms = gridsVrms;
        fieldname2 = fieldnames(meanFieldsA);
        fieldname3 = fieldnames(sigmau1);
        averSigmau1_all = sigmau1;
        averSigmau2_all = sigmau2;
    else
        for i = 1:numel(fieldname1)
            EulerStats.(fieldname1{i})=[EulerStats.(fieldname1{i});eulerStats.(fieldname1{i})];
        end
        averSigmau1_all = [averSigmau1_all;sigmau1];
        averSigmau2_all = [averSigmau2_all;sigmau2];   
    end

    for i = 1:numel(fieldname2)
        MeanFieldsA_allMatrices.(fieldname2{i}){:,kexp} = meanFieldsA.(fieldname2{i});
        MeanFieldsArms_allMatrices.(fieldname2{i}){:,kexp} = meanFieldsArms.(fieldname2{i});
        MeanFieldsV_allMatrices.(fieldname2{i}){:,kexp} = meanFieldsV.(fieldname2{i});
        MeanFieldsVrms_allMatrices.(fieldname2{i}){:,kexp} = meanFieldsVrms.(fieldname2{i});
        SigmauFields_allMatrices.(fieldname2{i}){:,kexp} = sigmauFields.(fieldname2{i});
    end

    clear eulerStats gridsA gridsArms gridsV gridsVrms meanFieldsA meanFieldsArms meanFieldsV meanFieldsVrms sigmau1 sigmau2 sigmauFields
end
for i = 1:numel(fieldname3)
    averSigmau1.(fieldname3{i}) = mean(vertcat(averSigmau1_all.(fieldname3{i})));
    averSigmau2.(fieldname3{i}) = mean(vertcat(averSigmau2_all.(fieldname3{i})));  
end
for i = 1:numel(fieldname2)
    averMeanFieldsA.(fieldname2{i}) = averMeanFields(MeanFieldsA_allMatrices.(fieldname2{i}));
    averMeanFieldsArms.(fieldname2{i}) = averMeanFields(MeanFieldsArms_allMatrices.(fieldname2{i}));
    averMeanFieldsV.(fieldname2{i}) = averMeanFields(MeanFieldsV_allMatrices.(fieldname2{i}));
    averMeanFieldsVrms.(fieldname2{i}) = averMeanFields(MeanFieldsVrms_allMatrices.(fieldname2{i}));
    averSigmauFields.(fieldname2{i}) = averMeanFields(SigmauFields_allMatrices.(fieldname2{i}));
end
clear MeanFieldsA_allMatrices MeanFieldsArms_allMatrices MeanFieldsV_allMatrices MeanFieldsVrms_allMatrices SigmauFields_allMatrices


for kexp = 1:Nexp
    load([fmatEulerStats_subsMean filesep 'EulerianStats_' num2str(kexp) '.mat']); 
    if kexp == 1
        fieldname1 = fieldnames(eulerStats);
        for i = 1:numel(fieldname1)
            EulerStatsRMS.(fieldname1{i}) = eulerStats.(fieldname1{i});  
        end
    else
        for i = 1:numel(fieldname1)
            EulerStatsRMS.(fieldname1{i})=[EulerStatsRMS.(fieldname1{i});eulerStats.(fieldname1{i})];
        end
    end

    clear eulerStats 
end

averEulerStats = averEulerianStats(EulerStats);
averEulerStatsRMS = averEulerianStats(EulerStatsRMS);

save([figEuler 'averEulerStats.mat'],'averEulerStats','EulerStats')
save([figEulerSubsMean 'averEulerStatsRMS.mat'],'averEulerStatsRMS','EulerStatsRMS')
save([figEuler 'averMeanFields.mat'],'averGridsA','averGridsArms','averGridsV','averGridsVrms','averMeanFieldsA','averMeanFieldsArms','averMeanFieldsV','averMeanFieldsVrms')
save([figEuler 'averSigmau.mat'],'averSigmau1','averSigmau2','averSigmauFields','averSigmau1_all','averSigmau2_all')

%% Tracer: visualize the mean fields
slices.x = [-20 0 20];
slices.y = [0];
slices.z = [0];
axisrange = [-25 25 -25 25 -40 40]; % align gravity in vertical

sliceFields(averGridsV,averMeanFieldsV,slices,axisrange,1,1)
savefig_custom(figEuler,'averMeanFieldsV',16,5)
sliceFields(averGridsVrms,averMeanFieldsVrms,slices,axisrange,1,2)
savefig_custom(figEuler,'averMeanFieldsVrms',16,5)
sliceFields(averGridsA,averMeanFieldsA,slices,axisrange,2,1)
savefig_custom(figEuler,'averMeanFieldsA',16,5)
sliceFields(averGridsArms,averMeanFieldsArms,slices,axisrange,2,2)
savefig_custom(figEuler,'averMeanFieldsArms',16,5)


%% Tracer: Averaged dissipation rate
Ckolomogrov = 2.1;

Rmin = 1;
Rmax = 10;

for i = 1:2
    if i == 1
        ES = averEulerStats;
        foutES = figEuler;
    else
        ES = averEulerStatsRMS;
        foutES = figEulerSubsMean;
    end
    figure;
    loglog(ES.r,(ES.Splong{1,2}./Ckolomogrov).^(1.5)./ES.r,'d-',Color=color3(1,:));hold on
    loglog(ES.r,abs(ES.Splong{1,3})./(4/5*ES.r),'d-',Color=color3(2,:));
    loglog(ES.r,abs(ES.Sau)./2,'d-',Color=color3(3,:));
    
    legend('$(S_2^{\parallel}/C_k)^{3/2}\cdot r^{-1}$','$|S_3^{\parallel}|\cdot (4/5r)^{-1}$','$|S_{au}|/2$')
    ylabel('$\epsilon [mm^2/s^3]$')
    xlabel('$r [mm]$')
    grid on;axis padded
    
    ridx = find(ES.r<Rmax & ES.r>Rmin);
    epsilon = mean((ES.Splong{1,2}(ridx)./Ckolomogrov).^(1.5)./ES.r(ridx));

    savefig_custom(foutES,'Epsilon',8,7)
    save([foutES 'epsilon.mat'],'epsilon','Rmin','Rmax')
end

clear ES foutES ridx
%% Tracer: dissipation rate series

Ckolomogrov = 2.1;

Rmin = 1;
Rmax = 10;

ES = EulerStatsRMS; % we use RMS field to determin the dissipation rate

for kexp = 1:Nexp
    ridx = find(ES.r(kexp,:)<Rmax & ES.r(kexp,:)>Rmin);
    epsilonMean(kexp) = mean((ES.Splong{kexp,2}(ridx)/Ckolomogrov).^(1.5)./ES.r(kexp,ridx)');
    epsilonStd(kexp) = std((ES.Splong{kexp,2}(ridx)/Ckolomogrov).^(1.5)./ES.r(kexp,ridx)');
end
averEpsilonMean = mean(epsilonMean);
stdEpsilonMean = mean(epsilonMean);

figure
plot(epsilonMean,'d-',Color=color1);hold on
patch_x = [[1:1:Nexp], [Nexp:-1:1]];
patch_y = [epsilonMean+epsilonStd, fliplr(epsilonMean-epsilonStd)];
patch(patch_x, patch_y, color3(3,:), 'FaceAlpha', 0.3);
legend('$Mean[(S_2^{\parallel}/C_k)^{3/2}\cdot r^{-1}]$','$std.[(S_2^{\parallel}/C_k)^{3/2}\cdot r^{-1}]$')
ylabel('$\epsilon [mm^2/s^3]$')
xlabel('$N_{exp.}$')
grid on;axis padded
xlim([1 Nexp])

savefig_custom(figEulerSubsMean,'epsilonTime',8,7)
save([figEulerSubsMean 'epsilonTime.mat'],'epsilonMean','epsilonStd','averEpsilonMean','stdEpsilonMean','Rmin','Rmax')

clear ES ridx

%% Tracer: Kolmogorov scale
% epsilon = 0.247; % m2/s3

nu = 8e-7; % m2/s at 30°C

tau_eta = sqrt(nu/(epsilon*1e-6));
etaK = (nu^3/(epsilon*1e-6))^0.25;
save([figEulerSubsMean 'KolmogorovScales.mat'],'nu','tau_eta','etaK')


%% Tracer: Eulerian plots: check stationary

lagTime = (lagTimeX+lagTimeY+lagTimeZ)/3;

for i = 1:2
    if i == 1
        ES = averEulerStats;
        foutES = figEuler;
    else
        ES = averEulerStatsRMS;
        foutES = figEulerSubsMean;
    end
    
    xt = [1:1:numel(ES.Vmoy)]*ES.filtL/Fs/lagTime;
    figure
    t=tiledlayout(2,2,'TileSpacing','loose');
    nexttile;
    plot(xt,ES.Vmoy,'d-',Color=color1(1,:),MarkerSize=3);hold on
    plot(xt,ES.VmoyX,'-',Color=color3(1,:),MarkerSize=3);
    plot(xt,ES.VmoyY,'-',Color=color3(2,:),MarkerSize=3);
    plot(xt,ES.VmoyZ,'-',Color=color3(3,:),MarkerSize=3);
    set(gca,FontSize=15)
    legend('$\langle \sqrt{x^2+y^2+z^2} \rangle$','$\langle x \rangle$','$\langle y \rangle$','$\langle z \rangle$',Location='northoutside',FontSize=10);
    ylabel('$|u| [m/s]$')
    xlabel('$t/T_L$')
    axis tight
    grid on
    
    nexttile;
    plot(xt,ES.Vstd,'d-',Color=color1(1,:),MarkerSize=3);hold on
    plot(xt,ES.VstdX,'-',Color=color3(1,:),MarkerSize=3);
    plot(xt,ES.VstdY,'-',Color=color3(2,:),MarkerSize=3);
    plot(xt,ES.VstdZ,'-',Color=color3(3,:),MarkerSize=3);
    set(gca,FontSize=15)
    ylabel('$\sigma_u [m/s]$')
    xlabel('$t/T_L$')
    axis tight
    grid on
    
    nexttile;
    plot(xt,ES.Amoy,'d-',Color=color1(1,:),MarkerSize=3);hold on
    plot(xt,ES.AmoyX,'-',Color=color3(1,:),MarkerSize=3);
    plot(xt,ES.AmoyY,'-',Color=color3(2,:),MarkerSize=3);
    plot(xt,ES.AmoyZ,'-',Color=color3(3,:),MarkerSize=3);
    set(gca,FontSize=15)
    ylabel('$|a| [m/s^2]$')
    xlabel('$t/T_L$')
    axis tight
    grid on
    
    nexttile;
    plot(xt,ES.Astd,'d-',Color=color1(1,:),MarkerSize=3);hold on
    plot(xt,ES.AstdX,'-',Color=color3(1,:),MarkerSize=3);
    plot(xt,ES.AstdY,'-',Color=color3(2,:),MarkerSize=3);
    plot(xt,ES.AstdZ,'-',Color=color3(3,:),MarkerSize=3);
    set(gca,FontSize=15)
    ylabel('$\sigma_a [m/s^2]$')
    xlabel('$t/T_L$')
    axis tight
    grid on
    
    % linkaxes(t.Children,'x')

    savefig_custom(foutES,'VAt',14,7)
end

clear ES foutES xt


%% Tracer: Eulerian plots: 2nd order structure functio (S2x, S2y, S2z)
for i = 1:2
    if i == 1
        ES = averEulerStats;
        foutES = figEuler;
    else
        ES = averEulerStatsRMS;
        foutES = figEulerSubsMean;
    end
    
    figure
    t=tiledlayout(1,1,'TileSpacing','loose');
    ax1 = axes(t);
    loglog(ax1,ES.r,ES.S2x,'d-',Color=color3(1,:));hold on
    loglog(ax1,ES.r,ES.S2y,'d-',Color=color3(2,:));
    loglog(ax1,ES.r,ES.S2z,'d-',Color=color3(3,:));
    
    loglog(ax1,ES.r,9e3*ES.r.^(2/3),'--',Color=color1)
    % loglog(eulerStats.r(end-30:end),7e3*eulerStats.r(end-30:end).^(1/3),'--',Color=color1)
    
    legend('x','y','z')
    ylabel('$S_2^E [mm^2/s]$')
    xlabel('$r [mm]$')
    text(3,3e4,'$r^{2/3}$',FontSize=18,FontWeight='bold')
    % text(30,1.5e4,'$r^{1/3}$',FontSize=18,FontWeight='bold')
    grid on
    axis padded
    
%     ax2 = axes('Position', get(ax1,'Position'), ...
%         'XAxisLocation','top', ...
%         'Color','none', ...
%         'XColor','k');
%     ax2.YAxis.Visible = 'off';
%     ax2.XLim = ax1.XLim/(etaK*1e3);
%     ax2.XScale = 'log';
%     xlabel(ax2,'$r/\eta_K$')
    savefig_custom(foutES,'S2E',8,7)
end

clear ES foutES 

%% Tracer: Eulerian plots: Ruu 
for i = 1:2
    if i == 1
        ES = averEulerStats;
        foutES = figEuler;
    else
        ES = averEulerStatsRMS;
        foutES = figEulerSubsMean;
    end
    
    figure
    plot(ES.Ruur,ES.Ruu,'-',Color=color3(1,:));hold on
    set(gca,FontSize=15)
    ylabel('$Ruu(r)$')
    xlabel('$Ruu_r$')
    grid on
    axis padded
    
    savefig_custom(foutES,'Ruu',8,7)
    
end

clear ES foutES 

%% Tracer: Eulerian plots: PSD

for i = 1:2
    if i == 1
        ES = averEulerStats;
        foutES = figEuler;
    else
        ES = averEulerStatsRMS;
        foutES = figEulerSubsMean;
    end
    
    figure
    loglog(ES.PSDk,ES.PSD,'-',Color=color3(1,:));hold on
    ylabel('$PSD$')
    xlabel('$k [mm^{-1}]$')
    grid on
    axis padded
    
    savefig_custom(foutES,'PSD',8,7)
end

clear ES foutES 

%% Tracer: Eulerian plots: Sau

for i = 1:2
    if i == 1
        ES = averEulerStats;
        foutES = figEuler;
    else
        ES = averEulerStatsRMS;
        foutES = figEulerSubsMean;
    end
    
    figure
    t = tiledlayout(1,1);
    ax1 = axes(t);    
    semilogx(ax1,ES.r,ES.Sau,'d-',Color=color3(1,:));hold on
    semilogx(ax1,ES.r,ES.Saulong,'d-',Color=color3(3,:)); 
    legend('$S_{au}$','$S_{au}^{\parallel}$')
    ylabel('$S_{au}, S_{au}^{\parallel} [mm^2/s^3]$')
    xlabel('$r [mm]$')
    grid on
    axis padded
    
    savefig_custom(foutES,'Sau',8,7)
end

clear ES foutES 

%% Tracer: Eulerian plots: Splong
for i = 1:2
    if i == 1
        ES = averEulerStats;
        foutES = figEuler;
    else
        ES = averEulerStatsRMS;
        foutES = figEulerSubsMean;
    end
    
    figure
    loglog(ES.r,ES.Splong{1,1},'d-',Color=color5(1,:));hold on
    loglog(ES.r,ES.Splong{1,2},'d-',Color=color5(2,:));
    loglog(ES.r,ES.Splong{1,3},'d-',Color=color5(3,:));
    loglog(ES.r,ES.Splong{1,4},'d-',Color=color5(4,:));
    loglog(ES.r,ES.Splong{1,5},'d-',Color=color5(5,:));
    
    rSplong = linspace(0.4,100,100);
    loglog(rSplong,6e1*rSplong.^(1/3),'--',Color=color1)
    loglog(rSplong,5e3*rSplong.^(2/3),'--',Color=color1)
    loglog(rSplong,9e5*rSplong.^(3/3),'--',Color=color1)
    loglog(rSplong,1e8*rSplong.^(4/3),'--',Color=color1)
    loglog(rSplong,3e10*rSplong.^(5/3),'--',Color=color1)
    
    legend('$S_1^{\parallel}$','$S_2^{\parallel}$','$S_3^{\parallel}$','$S_4^{\parallel}$','$S_5^{\parallel}$')
    ylabel('$S_p^{\parallel} [mm^n/s^n]$')
    xlabel('$r [mm]$')
    text(8,5e12,'$r^{5/3}$')
    text(8,2e10,'$r^{4/3}$')
    text(8,5e7,'$r^{3/3}$')
    text(8,3e5,'$r^{2/3}$')
    text(8,5e2,'$r^{1/3}$')
    grid on
    axis padded
    
    savefig_custom(foutES,'Splong',8,7)
end

clear ES foutES

%% Tracer: Eulerian plots: SplongAbs
for i = 1:2
    if i == 1
        ES = averEulerStats;
        foutES = figEuler;
    else
        ES = averEulerStatsRMS;
        foutES = figEulerSubsMean;
    end
    
    figure
    loglog(ES.r,ES.SplongAbs{1,1},'d-',Color=color5(1,:));hold on
    loglog(ES.r,ES.SplongAbs{1,2},'d-',Color=color5(2,:));
    loglog(ES.r,ES.SplongAbs{1,3},'d-',Color=color5(3,:));
    loglog(ES.r,ES.SplongAbs{1,4},'d-',Color=color5(4,:));
    loglog(ES.r,ES.SplongAbs{1,5},'d-',Color=color5(5,:));
    
    rSplong = linspace(0.4,100,100);
    loglog(rSplong,6e1*rSplong.^(1/3),'--',Color=color1)
    loglog(rSplong,5e3*rSplong.^(2/3),'--',Color=color1)
    loglog(rSplong,9e5*rSplong.^(3/3),'--',Color=color1)
    loglog(rSplong,1e8*rSplong.^(4/3),'--',Color=color1)
    loglog(rSplong,3e10*rSplong.^(5/3),'--',Color=color1)
    
    legend('$S_1^{\parallel}$','$S_2^{\parallel}$','$S_3^{\parallel}$','$S_4^{\parallel}$','$S_5^{\parallel}$')
    ylabel('$S_p^{\parallel} [mm^n/s^n]$')
    xlabel('$r [mm]$')
    text(8,5e12,'$r^{5/3}$')
    text(8,2e10,'$r^{4/3}$')
    text(8,5e7,'$r^{3/3}$')
    text(8,3e5,'$r^{2/3}$')
    text(8,5e2,'$r^{1/3}$')
    grid on
    axis padded
    
    savefig_custom(foutES,'SplongAbs',8,7)
end

clear ES foutES

%% Particle: output path
fpathP = [pwd filesep 'particle' filesep];
fpathP_STB = [pwd filesep 'particle' filesep 'Seperate_Files_STB' filesep];

figLagr = [fpathP 'Figures_Lagr' filesep];
fmatTracks = [fpathP 'Tracks' filesep];
fmatLagrStats = [fpathP 'LagrangianStats' filesep];
figTraj = [fpathP 'Figures_traj' filesep];

mkdir(figLagr)
mkdir(fmatTracks)
mkdir(fmatLagrStats)
mkdir(figTraj)
%% Particle: find proper filter width

% idx_maxT = 44;

ifParticle = 1;
frame0 = 0;
long_thres = 5;
[track,Ilong] = buildTracks(fpathP_STB,['STB_' num2str(idx_maxT) '.mat'],ifParticle,frame0,long_thres);
[s,m,w] = findOptimalFilterWidth(track,Ilong);

%% Particle: set values for gaussian filter
wopt = 6;
lopt = 20;

%% Particle: plot std
plot([wopt wopt],ylim,'--',Color=color1)
savefig_custom(figLagr,'Std',8,7)

%% Particle: iteration over each experiments
% ifParticle = 1;
% frame0 = 0;
% long_thres = 5;
for i = 1:Nexp
    fnamein = ['STB_' num2str(i) '.mat'];
    [track,Ilong] = buildTracks(fpathP_STB,fnamein,ifParticle,frame0,long_thres);
    
    % Particle: Estimate smoothed tracks with optimal filter width
    tracklong_particle=calcVelLEM(track(Ilong),wopt,lopt,Fs);
    Ine=arrayfun(@(X)(~isempty(X.Vx)),tracklong_particle)==1;
    tracklong_particle = tracklong_particle(Ine);

    fnameout1 = ['tracks_' num2str(i) '.mat'];
    save([fmatTracks filesep fnameout1],'long_thres','tracklong_particle','wopt','lopt','Fs')
    
    fnameout2 = ['LagrangianStats_' num2str(i) '.mat'];
    save([fmatLagrStats filesep fnameout2],'s','w','wopt','lopt')
    
    clear track Ilong Ine

end

%% Particle: merge tracklong_particle

for i = 1:Nexp
    data = load([fmatTracks filesep 'tracks_' num2str(i) '.mat']);
    if size(data.tracklong_particle,2)>1
        data.tracklong_particle = mergeStructures(data.tracklong_particle);
    end
    if i == 1
        tracklong_particle = data.tracklong_particle;
    else
        tracklong_particle = mergeStruct(tracklong_particle,data.tracklong_particle);
    end
end

%% Particle: plot trajectory, V(t), A(t)

x0 = mean(cell2mat(arrayfun(@(X)(X.Xf(1)),tracklong_particle,UniformOutput=false)));
y0 = mean(cell2mat(arrayfun(@(X)(X.Yf(1)),tracklong_particle,UniformOutput=false)));
z0 = mean(cell2mat(arrayfun(@(X)(X.Zf(1)),tracklong_particle,UniformOutput=false)));
origin = [x0,y0,z0];

axisrange_traj = [-20 20 -20 20 -40 40];
axisrange_vat = [0.05 0.3];
startTime = 50;% number of frames after the particle detected
endTime = 350;% number of frames after the particle detected

plot_traj(tracklong_particle,origin,axisrange_traj,1,figTraj);
[tinterp,tAverVyStart,tAverVyend,Vpg,Vpg_ts,ay] = plot_VAt(tracklong_particle,startTime,endTime,axisrange_vat,Fs,1,figTraj);

save([figTraj 'origin.mat'],'origin');
save([figTraj 'Vp.mat'],'tinterp','tAverVyStart','tAverVyend','Vpg','Vpg_ts','ay','startTime','endTime');

clear axisrange_traj axisrange_vat


%% Particle: save Lagrangian Stats

pdf.Nbins = 256;
pdf.n = 10;
ndt.start = [8 8 8];
ndt.len = [10 10 10];

LagStatsParticle = LagragianStatParticle(tracklong_particle,Fs,pdf,ndt);
save([figLagr 'LagrangianStats.mat'],'LagStatsParticle')

%% Particle: plot PDFs
figure;
semilogy(LagStatsParticle.pdfVx.xpdfn,LagStatsParticle.pdfVx.pdfn,'d-',Color=color3(1,:));hold on;
semilogy(LagStatsParticle.pdfVy.xpdfn,LagStatsParticle.pdfVy.pdfn,'d-',Color=color3(2,:));hold on;
semilogy(LagStatsParticle.pdfVz.xpdfn,LagStatsParticle.pdfVz.pdfn,'d-',Color=color3(3,:));hold on;
semilogy(LagStatsParticle.pdfAx.xpdfn,LagStatsParticle.pdfAx.pdfn,'o-',Color=color3(1,:));hold on;
semilogy(LagStatsParticle.pdfAy.xpdfn,LagStatsParticle.pdfAy.pdfn,'o-',Color=color3(2,:));hold on;
semilogy(LagStatsParticle.pdfAz.xpdfn,LagStatsParticle.pdfAz.pdfn,'o-',Color=color3(3,:));hold on;

xpdf=linspace(-4,4,1024);
plot(xpdf,normpdf(xpdf,0,1),Color=color1);

legend('$u_x$','$u_y$','$u_z$','$a_x$','$a_y$','$a_z$');
ylabel('$PDF$')
xlabel('$u, a$')
grid on
axis padded
clear xpdf
savefig_custom(figLagr,'PDFs',16,6)

%% Particle: plot MSD
figure;
loglog(LagStatsParticle.MSDx.tau/Fs,LagStatsParticle.MSDx.mean,'d-',Color=color3(1,:));hold on;
loglog(LagStatsParticle.MSDy.tau/Fs,LagStatsParticle.MSDy.mean,'d-',Color=color3(2,:));hold on;
loglog(LagStatsParticle.MSDz.tau/Fs,LagStatsParticle.MSDz.mean,'d-',Color=color3(3,:));hold on;

xMSD = linspace(1,max(LagStatsParticle.MSDx.tau),1000)/Fs;
loglog(xMSD,3e5*xMSD.^2,'--',Color=color1)

legend('x','y','z')
% title('$MSD$')
ylabel('$\sigma^2_{MSD} [mm^2]$')
xlabel('$t [s]$')
text(2e-3,3e-0,'$\tau^2$','FontSize',18,FontWeight='bold')
grid on
axis padded

clear xMSD
savefig_custom(figLagr,'MSDs',8,7)

%% Particle: plot S2L
figure;
loglog(LagStatsParticle.S2Lx.tau/Fs,LagStatsParticle.S2Lx.mean,'d-',Color=color3(1,:));hold on;
loglog(LagStatsParticle.S2Ly.tau/Fs,LagStatsParticle.S2Ly.mean,'d-',Color=color3(2,:));hold on;
loglog(LagStatsParticle.S2Lz.tau/Fs,LagStatsParticle.S2Lz.mean,'d-',Color=color3(3,:));hold on;

xS2L = linspace(1,20,100)/Fs;
loglog(xS2L,8e7*xS2L.^2,'--',Color=color1)

xS2L = linspace(8,100,100)/Fs;
loglog(xS2L,9e6*xS2L.^(8/5),'--',Color=color1)

legend('x','y','z')
ylabel('$S_2^L [mm^2/s^2]$')
xlabel('$t [s]$')
text(8e-4,9e1,'$\tau^2$',FontSize=18,FontWeight='bold')
text(8e-3,1e4,'$\tau^{8/5}$',FontSize=18,FontWeight='bold')
grid on
axis padded

clear xS2L
savefig_custom(figLagr,'S2L',8,7)

%% Particle: plot Correlation function (fit)

% !!!! key params to make the fits better !!!!
% in correlationFit2.m, startpoints, lowerpoints, upperpoints are crucial!!
nCorrFitV = [100 150 200];
nCorrFitAstart = [1 15 1];
nCorrFitAend = [20 60 20];
if2layersV = 1;
if2layersA = 1;
ifboundedV = [1 1 1]; 
ifboundedA = [1 1 1];

Ruufitx = correlationFit2(LagStatsParticle.Ruux.tau/Fs,LagStatsParticle.Ruux.mean,1,nCorrFitV(1),'V',if2layersV,ifboundedV(1));
Ruufity = correlationFit2(LagStatsParticle.Ruuy.tau/Fs,LagStatsParticle.Ruuy.mean,1,nCorrFitV(2),'V',if2layersV,ifboundedV(2));
Ruufitz = correlationFit2(LagStatsParticle.Ruuz.tau/Fs,LagStatsParticle.Ruuz.mean,1,nCorrFitV(3),'V',if2layersV,ifboundedV(3));
Raafitx = correlationFit2(LagStatsParticle.Raax.tau/Fs,LagStatsParticle.Raax.mean,nCorrFitAstart(1),nCorrFitAend(1),'A',if2layersA,ifboundedA(1));
Raafity = correlationFit2(LagStatsParticle.Raay.tau/Fs,LagStatsParticle.Raay.mean,nCorrFitAstart(2),nCorrFitAend(2),'A',if2layersA,ifboundedA(2));
Raafitz = correlationFit2(LagStatsParticle.Raaz.tau/Fs,LagStatsParticle.Raaz.mean,nCorrFitAstart(3),nCorrFitAend(3),'A',if2layersA,ifboundedA(3));
clear nCorrFitV nCorrFitA if2layersV  if2layersA ifboundedV ifboundedA

ylimV = [-0.5 1];
ylimA = [-0.15 1];

figure;
tiledlayout(3,2,"TileSpacing","loose")

nexttile % ux
plot(LagStatsParticle.Ruux.tau/Fs,LagStatsParticle.Ruux.mean/LagStatsParticle.Ruux.mean(1),'d',Color=color3(1,:),MarkerSize=2);hold on
plot(Ruufitx.x,Ruufitx.yfit,'-',Color=color3(1,:));hold on
legend('$R_{uu}$','$R^{fit}_{uu}$',Location='northeast')
ylabel('$R^x_{uu}[m^2/s^2]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimV)
patch_x = [Ruufitx.x, fliplr(Ruufitx.x)];
patch_y = [Ruufitx.yfit', zeros(size(Ruufitx.yfit'))];
patch(patch_x, patch_y, color3(1,:), 'FaceAlpha', 0.3);
lagTimeX = trapz(patch_x, patch_y);


nexttile % ax
plot(LagStatsParticle.Raax.tau/Fs,LagStatsParticle.Raax.mean/LagStatsParticle.Raax.mean(1),'o',Color=color3(1,:),MarkerSize=2);hold on
plot(Raafitx.x,Raafitx.yfit,'-',Color=color3(1,:));hold on
legend('$R_{aa}$','$R^{fit}_{aa}$',Location='northwest')
ylabel('$R^x_{aa}[m^2/s^4]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimA)
patch_x = [Raafitx.x, fliplr(Raafitx.x)];
patch_y = [Raafitx.yfit', zeros(size(Raafitx.yfit'))];
patch(patch_x, max(patch_y, 0), color3(1,:), 'FaceAlpha', 0.3);
dissLagTimeX = trapz(patch_x, max(patch_y, 0));


nexttile % uy
plot(LagStatsParticle.Ruuy.tau/Fs,LagStatsParticle.Ruuy.mean/LagStatsParticle.Ruuy.mean(1),'d',Color=color3(2,:),MarkerSize=2);hold on
plot(Ruufity.x,Ruufity.yfit,'-',Color=color3(2,:));hold on
ylabel('$R^y_{uu}[m^2/s^2]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimV)
patch_x = [Ruufity.x, fliplr(Ruufity.x)];
patch_y = [Ruufity.yfit', zeros(size(Ruufity.yfit'))];
patch(patch_x, patch_y, color3(2,:), 'FaceAlpha', 0.3);
lagTimeY = trapz(patch_x, patch_y);

nexttile % ay
plot(LagStatsParticle.Raay.tau/Fs,LagStatsParticle.Raay.mean/LagStatsParticle.Raay.mean(1),'o',Color=color3(2,:),MarkerSize=2);hold on
plot(Raafity.x,Raafity.yfit,'-',Color=color3(2,:));hold on
ylabel('$R^y_{aa}[m^2/s^4]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimA)
patch_x = [Raafity.x, fliplr(Raafity.x)];
patch_y = [Raafity.yfit', zeros(size(Raafity.yfit'))];
patch(patch_x, max(patch_y, 0), color3(2,:), 'FaceAlpha', 0.3);
dissLagTimeY = trapz(patch_x, max(patch_y, 0));

nexttile % uz
plot(LagStatsParticle.Ruuz.tau/Fs,LagStatsParticle.Ruuz.mean/LagStatsParticle.Ruuz.mean(1),'d',Color=color3(3,:),MarkerSize=2);hold on
plot(Ruufitz.x,Ruufitz.yfit,'-',Color=color3(3,:));hold on
ylabel('$R^z_{uu}[m^2/s^2]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimV)
patch_x = [Ruufitz.x, fliplr(Ruufitz.x)];
patch_y = [Ruufitz.yfit', zeros(size(Ruufitz.yfit'))];
patch(patch_x, patch_y, color3(3,:), 'FaceAlpha', 0.3);
lagTimeZ = trapz(patch_x, patch_y);

nexttile % az
plot(LagStatsParticle.Raaz.tau/Fs,LagStatsParticle.Raaz.mean/LagStatsParticle.Raaz.mean(1),'o',Color=color3(3,:),MarkerSize=2);hold on
plot(Raafitz.x,Raafitz.yfit,'-',Color=color3(3,:));hold on
ylabel('$R^z_{aa}[m^2/s^4]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimA)
patch_x = [Raafitz.x, fliplr(Raafitz.x)];
patch_y = [Raafitz.yfit', zeros(size(Raafitz.yfit'))];
patch(patch_x, max(patch_y, 0), color3(3,:), 'FaceAlpha', 0.3);
dissLagTimeZ = trapz(patch_x, max(patch_y, 0));

savefig_custom(figLagr,'Corr',16,10)
save([figLagr 'timescale.mat'],'lagTimeX','lagTimeY','lagTimeZ','dissLagTimeX','dissLagTimeY','dissLagTimeZ')

%% Particle: plot Correlation function -- dt method (denosied) 

nCorrFitV = [100 150 200];
nCorrFitAstart = [10 1 10];
nCorrFitAend = [20 40 20];
if2layersV = 1;
if2layersA = 0;
ifboundedV = [1 1 1]; 
ifboundedA = [1 1 1];

dtRuufitx = correlationFit2(LagStatsParticle.dtCorrvX.tau,LagStatsParticle.dtCorrvX.corr,1,nCorrFitV(1),'V',if2layersV,ifboundedV(1));
dtRuufity = correlationFit2(LagStatsParticle.dtCorrvY.tau,LagStatsParticle.dtCorrvY.corr,1,nCorrFitV(2),'V',if2layersV,ifboundedV(2));
dtRuufitz = correlationFit2(LagStatsParticle.dtCorrvZ.tau,LagStatsParticle.dtCorrvZ.corr,1,nCorrFitV(3),'V',if2layersV,ifboundedV(3));
dtRaafitx = correlationFit2(LagStatsParticle.dtCorraX.tau,LagStatsParticle.dtCorraX.corr,nCorrFitAstart(1),nCorrFitAend(1),'A',if2layersA,ifboundedA(1));
dtRaafity = correlationFit2(LagStatsParticle.dtCorraY.tau,LagStatsParticle.dtCorraY.corr,nCorrFitAstart(2),nCorrFitAend(2),'A',if2layersA,ifboundedA(2));
dtRaafitz = correlationFit2(LagStatsParticle.dtCorraZ.tau,LagStatsParticle.dtCorraZ.corr,nCorrFitAstart(3),nCorrFitAend(3),'A',if2layersA,ifboundedA(3));
clear nCorrFitV nCorrFitA if2layersV  if2layersA ifboundedV ifboundedA

ylimV = [-0.5 1];
ylimA = [-0.15 1];

figure;
tiledlayout(3,2,"TileSpacing","loose")

nexttile % ux
plot(LagStatsParticle.dtCorrvX.tau,LagStatsParticle.dtCorrvX.corr/LagStatsParticle.dtCorrvX.corr(1),'d',Color=color3(1,:),MarkerSize=2);hold on
plot(dtRuufitx.x,dtRuufitx.yfit,'-',Color=color3(1,:));hold on
legend('$R_{uu}$','$R^{fit}_{uu}$',Location='northeast')
ylabel('$R^x_{uu}[m^2/s^2]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimV)
patch_x = [dtRuufitx.x, fliplr(dtRuufitx.x)];
patch_y = [dtRuufitx.yfit', zeros(size(dtRuufitx.yfit'))];
patch(patch_x, patch_y, color3(1,:), 'FaceAlpha', 0.3);
lagTimeX = trapz(patch_x, patch_y);


nexttile % ax
plot(LagStatsParticle.dtCorraX.tau,LagStatsParticle.dtCorraX.corr/LagStatsParticle.dtCorraX.corr(1),'o',Color=color3(1,:),MarkerSize=2);hold on
plot(dtRaafitx.x,dtRaafitx.yfit,'-',Color=color3(1,:));hold on
legend('$R_{aa}$','$R^{fit}_{aa}$',Location='northeast')
ylabel('$R^x_{aa}[m^2/s^4]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimA)
patch_x = [dtRaafitx.x, fliplr(dtRaafitx.x)];
patch_y = [dtRaafitx.yfit', zeros(size(dtRaafitx.yfit'))];
patch(patch_x, max(patch_y, 0), color3(3,:), 'FaceAlpha', 0.3);
dissLagTimeX = trapz(patch_x, max(patch_y, 0));


nexttile % uy
plot(LagStatsParticle.dtCorrvY.tau,LagStatsParticle.dtCorrvY.corr/LagStatsParticle.dtCorrvY.corr(1),'d',Color=color3(2,:),MarkerSize=2);hold on
plot(dtRuufity.x,dtRuufity.yfit,'-',Color=color3(2,:));hold on
ylabel('$R^y_{uu}[m^2/s^2]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimV)
patch_x = [dtRuufity.x, fliplr(dtRuufity.x)];
patch_y = [dtRuufity.yfit', zeros(size(dtRuufity.yfit'))];
patch(patch_x, patch_y, color3(2,:), 'FaceAlpha', 0.3);
lagTimeY = trapz(patch_x, patch_y);

nexttile % ay
plot(LagStatsParticle.dtCorraY.tau,LagStatsParticle.dtCorraY.corr/LagStatsParticle.dtCorraY.corr(1),'o',Color=color3(2,:),MarkerSize=2);hold on
plot(dtRaafity.x,dtRaafity.yfit,'-',Color=color3(2,:));hold on
ylabel('$R^y_{aa}[m^2/s^4]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimA)
patch_x = [dtRaafity.x, fliplr(dtRaafity.x)];
patch_y = [dtRaafity.yfit', zeros(size(dtRaafity.yfit'))];
patch(patch_x, max(patch_y, 0), color3(3,:), 'FaceAlpha', 0.3);
dissLagTimeY = trapz(patch_x, max(patch_y, 0));


nexttile % uz
plot(LagStatsParticle.dtCorrvZ.tau,LagStatsParticle.dtCorrvZ.corr/LagStatsParticle.dtCorrvZ.corr(1),'d',Color=color3(3,:),MarkerSize=2);hold on
plot(dtRuufitz.x,dtRuufitz.yfit,'-',Color=color3(3,:));hold on
ylabel('$R^z_{uu}[m^2/s^2]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimV)
patch_x = [dtRuufitz.x, fliplr(dtRuufitz.x)];
patch_y = [dtRuufitz.yfit', zeros(size(dtRuufitz.yfit'))];
patch(patch_x, patch_y, color3(3,:), 'FaceAlpha', 0.3);
lagTimeZ = trapz(patch_x, patch_y);


nexttile % az
plot(LagStatsParticle.dtCorraZ.tau,LagStatsParticle.dtCorraZ.corr/LagStatsParticle.dtCorraZ.corr(1),'o',Color=color3(3,:),MarkerSize=2);hold on
plot(dtRaafitz.x,dtRaafitz.yfit,'-',Color=color3(3,:));hold on
ylabel('$R^z_{aa}[m^2/s^4]$');
xlabel('$t [s]$')
grid on
axis tight
ylim(ylimA)
patch_x = [dtRaafitz.x, fliplr(dtRaafitz.x)];
patch_y = [dtRaafitz.yfit', zeros(size(dtRaafitz.yfit'))];
patch(patch_x, max(patch_y, 0), color3(3,:), 'FaceAlpha', 0.3);
dissLagTimeZ = trapz(patch_x, max(patch_y, 0));

savefig_custom(figLagr,'dtCorr',16,10)
save([figLagr 'timescale_dt.mat'],'lagTimeX','lagTimeY','lagTimeZ','dissLagTimeX','dissLagTimeY','dissLagTimeZ')

%% BOTH: path setting
fpathT = [pwd filesep 'tracers' filesep];
fpathP = [pwd filesep 'particle' filesep];

fpathT_tracks = [fpathT 'Tracks' filesep];
fpathP_tracks = [fpathP 'Tracks' filesep];

fpathP_slipVeloData = ['.' filesep 'slipVeloData' filesep];
mkdir(fpathP_slipVeloData)

%% BOTH: experiment parameters
mp = 0.0048e-3;%kg
dp = 1.0094e-3;%m
rhof = 995.67; %kg/m3
geff = 1; %ratio to 9.8m/s2

taup = tAverVyend-tAverVyStart; % determine from the plots of V(t) and Vs(t)
Vpg_tsMS = abs(Vpg_ts*1e-3); % abs, here we use m/s

sigmauMS = averSigmau2.all*1e-3; %m/s
epsilonMS = epsilon*1e-6;%m2/s3

params = expParam(Fs,mp,dp,rhof,nu,geff,taup,Vpg_tsMS,epsilonMS,sigmauMS);
save([pwd filesep 'expParams.mat'],'params');

clear mp dp rhof nv geff taup 

%% BOTH: tracking video
kexp = 44;
trajlen = 100;
trajincrp = 10;
trajincrt = 1;

Rmin = 0;
Rmax = 10;

Vmin = -400;
Vmax = 400;

load([fpathP 'origin.mat'])
load([fpathP_tracks 'tracks_' num2str(kexp) '.mat'],'tracklong_particle')
load([fpathT_tracks 'tracks_' num2str(kexp) '.mat'],'tracklong_tracers')
if size(tracklong_particle,2)>1
    tracklong_particle = mergeStructures(tracklong_particle);
end
particle_part = convertTrack(tracklong_particle); 
tracer_part = convertTrack(tracklong_tracers);

video3Dtraj2(particle_part,tracer_part,origin,trajlen,trajincrp,trajincrt,Rmin,Rmax,Vmin,Vmax);

clear nexp trajlen trajincrp trajincrt Rmin

%% BOTH: Iterate over experiments

% set the radius range of the 'tracers shell around big particle'
Rmin = 0;
Rmax = 10;

for kexp = 1:Nexp
    fname = ['tracks_' num2str(kexp) '.mat'];
    load([fpathT_tracks fname],'tracklong_tracers') % particle's trajectory struct
    load([fpathP_tracks fname],'tracklong_particle') % tracers's trajectory struct

    if size(tracklong_particle,2)>1
        tracklong_particle = mergeStructures(tracklong_particle);
    end
    
    % convert from 1*N structure(sorted by different tracks) to 1*1 structure
    particle_part = convertTrack(tracklong_particle); 
    tracer_part = convertTrack(tracklong_tracers);

    % find terminal state where a ~= 0, set the RelThres to a large value
    % to include the whole trajectory from the beginning  
%     [maxTimeLength, startTime, endTime, ThresErrorTS] = findTimeRange(particle_part.Ay, 100);
    startTime0 = startTime;
    endTime0 = min(endTime,numel(particle_part.Tf));

    % returns the vertical particle settling velcoity in terminal state
    Vpg(kexp,1) = mean(particle_part.Vy(startTime0:endTime0));
    
    % find the index of neighboring tracers of big particle at each frame
    neighborIdxAll = neighbor(particle_part,tracer_part,Rmin,Rmax,kexp);
    
    % returns the relative slip velocity in cylindrical coordinates
    % belowing two are basically the same and give the same results
    slipVeloCylind = slipVeloCylinderical(particle_part,tracer_part,neighborIdxAll,startTime0,endTime0);
%     slipVeloCylind = slipVeloCylinderical2(particle_part,tracer_part,neighborIdxAll,startTime,endTime);

    save([fpathP_slipVeloData 'slipVeloCylind_',num2str(kexp),'.mat'],'neighborIdxAll','slipVeloCylind');
end

% returns the mean vertical settling velocity of the big particle over all videos
% Vp>0, as we align the particle propagation to positive z-axis in slipVeloCylinderical.m
% meanVpg = abs(mean(Vpg)); 


%% BOTH: slip velocity averaged over experiments

% Initialize variables for storing sum and mean of relative velocities
nbinr = 30;
nbint = 30;
nidxmax = 1000;

for kexp = 1:Nexp
    Urel_allMatrices.x{:,kexp} = zeros(nbinr,nbint,nidxmax)*NaN;
    Urel_allMatrices.y{:,kexp} = zeros(nbinr,nbint,nidxmax)*NaN;
    Urel_allMatrices.z{:,kexp} = zeros(nbinr,nbint,nidxmax)*NaN;
end
fieldname = fieldnames(Urel_allMatrices);

% Create a spherical mesh
[rr,tt,~,~,X,Y] = SphericalMesh([Rmin Rmax],nbinr,nbint);

% Loop over different experiments (kexp)
for kexp = 1:Nexp
    % Load slip velocity data for the current experiment
    fname = ['slipVeloCylind_',num2str(kexp),'.mat'];
    load([fpathP_slipVeloData fname],'slipVeloCylind')
    
    % Extract relevant columns from slip velocity data
    rho = vertcat(slipVeloCylind.rho);
    theta = vertcat(slipVeloCylind.theta);
    z = vertcat(slipVeloCylind.z);
    urel = vertcat(slipVeloCylind.Urel);

    Urel.x = urel(:,1); 
    Urel.y = urel(:,2); 
    Urel.z = urel(:,3); 
%     Urel.norm = cell2mat(arrayfun(@(X) sqrt(X.x.^2+X.y.^2+X.z.^2),Urel,'UniformOutput',false));

    % Transform cylindrical coordinates to 2D polar coordinates
    rho2D = sqrt(rho.^2 + z.^2);
    theta2D = atan2(rho,z);

    % Iterate over each bin and calculate the sum of Urel
    for i = 1:nbinr-1
        for j = 1:nbint-1
            ind = find(rho2D >= rr(i) & rho2D < rr(i+1) & theta2D >= tt(j) & theta2D< tt(j+1));
            if numel(ind)~=0
                for kf = 1:numel(fieldname)
                    extendedVector = nan(1, nidxmax);
                    extendedVector(1:numel(ind)) = Urel.(fieldname{kf})(ind);
                    Urel_allMatrices.(fieldname{kf}){:,kexp}(j,i,:) = extendedVector;
                end
            end
            
        end
    end
    clear slipVeloCylind
end

for i = 1:numel(fieldname)
    [averMeanUrel.(fieldname{i}), averStdUrel.(fieldname{i}),countUrel] = averUrelMap(Urel_allMatrices.(fieldname{i}));
end
clear Urel_allMatrices

save([fpathP_slipVeloData 'averUrel.mat'],'averMeanUrel','averStdUrel','countUrel')

%% Plot the binned mean values using pseudocolor

etaKMMS = etaK*1e3; % mm

Vpg_tsABS = 403.32; % absValue of the case without turburlence, here we use mm/s

subscripts = {'\rho','\theta','z'};
fnamesub = {'rho','theta','z'};
for i = 1:2
    for kf = 1:numel(fieldname)
        if i == 1
            averUrel = averMeanUrel;
            colstr = ['$\langle U^{rel}_{' subscripts{kf} '}\rangle/\langle V^{Re=0}_{g} \rangle$'];
            fnamestr = 'mean';
            caxisLim = [-1 0];
        else
            averUrel = averStdUrel;
            colstr = ['$\sigma( U^{rel}_{' subscripts{kf} '})/\langle V^{Re=0}_{g} \rangle$'];
            fnamestr = 'std';
            caxisLim = [0 1];
        end
        figure;
        pcolor(X/etaKMMS,Y/etaKMMS, averUrel.(fieldname{kf})/Vpg_tsABS);
        xlabel('$z/\eta_K$');
        ylabel('$r/\eta_K$');
    %     colormap(parula(32))
        col =colorbar;
        caxis(caxisLim)
        hold on
        rectangle('Position', [[0, 0] - 0.5, 2*0.5, 2*0.5]/etaKMMS, 'Curvature', [1, 1], 'EdgeColor', 'b','FaceColor','k');
        quiver(0, 0, 4/etaKMMS, 0, 0, 'r', 'LineWidth', 6);
    %     rectangle('Position', [[0, 0] - 1, 2*1, 2*1]*2/etaK, 'Curvature', [1, 1], 'EdgeColor', 'r','LineStyle','--',LineWidth=2);
        ylabel(col,colstr,'interpreter','latex')
        col.TickLabelInterpreter = "latex";
        savefig_custom(fpathP_slipVeloData,[fnamestr 'Urel_' fnamesub{kf}],14,7)
    end
end

figure;
pcolor(X/etaKMMS,Y/etaKMMS, countUrel);
xlabel('$z/\eta_K$');
ylabel('$r/\eta_K$');
% colormap(parula(32))
col =colorbar;
caxis([100 5000])
hold on
rectangle('Position', [[0, 0] - 0.5, 2*0.5, 2*0.5]/etaKMMS, 'Curvature', [1, 1], 'EdgeColor', 'b','FaceColor','k');
quiver(0, 0, 4/etaKMMS, 0, 0, 'r', 'LineWidth', 6);
rectangle('Position', [[0, 0] - 1, 2*1, 2*1]*2/etaKMMS, 'Curvature', [1, 1], 'EdgeColor', 'r','LineStyle','--',LineWidth=2);
ylabel(col,'$N_{count}$','interpreter','latex')
col.TickLabelInterpreter = "latex";
savefig_custom(fpathP_slipVeloData,'Urel_count',14,7)

%% if not normalize by quiesent flow settling Vp:

etaKMMS = etaK*1e3; % mm

subscripts = {'\rho','\theta','z'};
fnamesub = {'rho','theta','z'};
for i = 1:2
    for kf = 1:numel(fieldname)
        if i == 1
            averUrel = averMeanUrel;
            colstr = ['$\langle U^{rel}_{' subscripts{kf} '}\rangle$'];
            fnamestr = 'mean';
        else
            averUrel = averStdUrel;
            colstr = ['$\sigma( U^{rel}_{' subscripts{kf} '})$'];
            fnamestr = 'std';
        end
        figure;
        pcolor(X/etaKMMS,Y/etaKMMS, averUrel.(fieldname{kf}));
        xlabel('$z/\eta_K$');
        ylabel('$r/\eta_K$');
    %     colormap(parula(32))
        col =colorbar;
        hold on
        rectangle('Position', [[0, 0] - 0.5, 2*0.5, 2*0.5]/etaKMMS, 'Curvature', [1, 1], 'EdgeColor', 'b','FaceColor','k');
        quiver(0, 0, 4/etaKMMS, 0, 0, 'r', 'LineWidth', 6);
    %     rectangle('Position', [[0, 0] - 1, 2*1, 2*1]*2/etaK, 'Curvature', [1, 1], 'EdgeColor', 'r','LineStyle','--',LineWidth=2);
        ylabel(col,colstr,'interpreter','latex')
        col.TickLabelInterpreter = "latex";
        savefig_custom(fpathP_slipVeloData,[fnamestr 'UrelNotNorm_' fnamesub{kf}],14,7)
    end
end