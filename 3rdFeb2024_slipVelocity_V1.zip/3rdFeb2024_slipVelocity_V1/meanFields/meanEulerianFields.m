function meanEulerianFields(fin,Fs,dt,nbins,threshold,gridRange,fEulerStats,ftracks_subsMean,kexp)


load([fin 'tracks_' num2str(kexp) '.mat'],'tracklong_tracers');


%% Tracer: compute the mean fields and substract it
[gridsV,meanFieldsV,tracklong_tracers] = meanFields(tracklong_tracers,Fs,dt,nbins,threshold,1,1,gridRange,0);
[gridsVrms,meanFieldsVrms,tracklong_tracers] = meanFields(tracklong_tracers,Fs,dt,nbins,threshold,1,2,gridRange,0);
[gridsA,meanFieldsA,tracklong_tracers] = meanFields(tracklong_tracers,Fs,dt,nbins,threshold,2,1,gridRange,0);
[gridsArms,meanFieldsArms,tracklong_tracers] = meanFields(tracklong_tracers,Fs,dt,nbins,threshold,2,2,gridRange,0);
% ------>>>>>>>>
% now the tracklong contains the rms fields
save([fEulerStats 'EulerianStats_' num2str(kexp) '.mat'],'gridsV','gridsVrms','gridsA','gridsArms', ...
    'meanFieldsV','meanFieldsVrms','meanFieldsA','meanFieldsArms','-append');  


%% Tracer: compute the fluctuation of fluid velocity sigma_u = sqrt(<u'^2>)
sigmau1.x = sqrt(mean(vertcat(tracklong_tracers.sVx).^2,"omitnan"));
sigmau1.y = sqrt(mean(vertcat(tracklong_tracers.sVy).^2,"omitnan"));
sigmau1.z = sqrt(mean(vertcat(tracklong_tracers.sVz).^2,"omitnan"));
sigmau1.all = sqrt((sigmau1.x^2+sigmau1.y^2+sigmau1.z^2)/3); % unit: mm/s
save([fEulerStats 'EulerianStats_' num2str(kexp) '.mat'],'sigmau1','-append');  

%% Tracer: compute the fluctuation of fluid velocity sigma_u = sqrt(<u^2>-<u>^2)
[sigmauFields,sigmau2] = rmsFlucVelo(meanFieldsV,meanFieldsVrms);
sigmau2.all = sqrt((sigmau2.x^2+sigmau2.y^2+sigmau2.z^2)/3); % unit: mm/s

save([fEulerStats 'EulerianStats_' num2str(kexp) '.mat'],'sigmauFields','sigmau2','-append');  
%% Tracer: get the rms fields
% tracklong_tracers: contains only the rms fields
tracklong_tracers = trackSubsMean(tracklong_tracers);
save([ftracks_subsMean 'tracks_' num2str(kexp) '.mat'],'tracklong_tracers')

    
