function fluidVelo = get_sampledVelo(particle_part, tracers_part, neighborIdxAll, FV)

    % Initialize structure to store slip velocity information
    fluidVelo = struct(); 

    ii = 0;
    for idxp = 1:numel(particle_part.Tf)
        ii = ii + 1;
        % 'Y' component is the gravity direction
        fluidVelo.sampledUx(ii) = mean(tracers_part.Vx(neighborIdxAll(idxp).idx)); % u_{z,e}
        fluidVelo.sampledUy(ii) = mean(tracers_part.Vy(neighborIdxAll(idxp).idx));
        fluidVelo.sampledUz(ii) = mean(tracers_part.Vz(neighborIdxAll(idxp).idx));

        Xp = [particle_part.Xf(idxp), particle_part.Yf(idxp), particle_part.Zf(idxp)];
        Vp = [particle_part.Vx(idxp), particle_part.Vy(idxp), particle_part.Vz(idxp)]; % v_z

        fluidVelo.ensAverUx(ii) = FV.x(Xp(1),Xp(2),Xp(3));  % \overline{u}_z
        fluidVelo.ensAverUy(ii) = FV.y(Xp(1),Xp(2),Xp(3));
        fluidVelo.ensAverUz(ii) = FV.z(Xp(1),Xp(2),Xp(3));

        fluidVelo.settlingUx(ii) = Vp(1) - fluidVelo.ensAverUx(ii); % v_z - \overline{u}_z
        fluidVelo.settlingUy(ii) = Vp(2) - fluidVelo.ensAverUy(ii);
        fluidVelo.settlingUz(ii) = Vp(3) - fluidVelo.ensAverUz(ii);

        fluidVelo.slidingUx(ii) = Vp(1) - fluidVelo.sampledUx(ii); % v_z - u_{z,e}
        fluidVelo.slidingUy(ii) = Vp(2) - fluidVelo.sampledUy(ii);
        fluidVelo.slidingUz(ii) = Vp(3) - fluidVelo.sampledUz(ii);

        fluidVelo.samplingUx(ii) =  fluidVelo.sampledUx(ii) - fluidVelo.ensAverUx(ii); % = settlingUx - slidingUx = u_{z,e} - \overline{u}_z
        fluidVelo.samplingUy(ii) =  fluidVelo.sampledUy(ii) - fluidVelo.ensAverUy(ii);
        fluidVelo.samplingUz(ii) =  fluidVelo.sampledUz(ii) - fluidVelo.ensAverUz(ii);
    end
end
