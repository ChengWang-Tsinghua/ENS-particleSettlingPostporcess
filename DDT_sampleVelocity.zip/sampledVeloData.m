function [sampledFluidVelo,neighborIdxAll] = sampledVeloData(tracklong_particle,tracklong_tracers,Rmin,Rmax,FV)

% convert from 1*N structure(sorted by different tracks) to 1*1 structure
particle_part = convertTrack(tracklong_particle); 
tracer_part = convertTrack(tracklong_tracers);

% find the index of neighboring tracers of big particle at each frame
neighborIdxAll = get_neighbor_tracers(particle_part, tracer_part, Rmin, Rmax);

% returns the relative slip velocity in Spherical coordinates
sampledFluidVelo = get_sampledVelo(particle_part, tracer_part, neighborIdxAll, FV);