clear;clc;

%%
% set the radius range of the 'tracers shell around big particle'
% recommanded value that Bejamin and Cheng used.
Rmin = 2;
Rmax = 8; %% mm

load([pwd filesep 'Eulerian_meanFields.mat'],'FV')
%%
load([pwd filesep 'tracks_tracers.mat'],'tracklong_tracers') % tracers's trajectory struct 
load([pwd filesep 'tracks_particle.mat'],'tracklong_particle') % particle's trajectory struct

[sampledFluidVelo,neighborIdxAll] = sampledVeloData(tracklong_particle,tracklong_tracers,Rmin,Rmax,FV);

sampledUz_mean = mean(sampledFluidVelo.sampledUz,'omitnan');
ensAverUz_mean = mean(sampledFluidVelo.ensAverUz,'omitnan');
slidingUz_mean = mean(sampledFluidVelo.slidingUz,'omitnan');
settlingUz_mean = mean(sampledFluidVelo.settlingUz,'omitnan');
samplingUz_mean = mean(sampledFluidVelo.samplingUz,'omitnan');