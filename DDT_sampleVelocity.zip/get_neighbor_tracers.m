function neighborAll = get_neighbor_tracers(particle_part, tracer_part, Rmin, Rmax)

    % Iterate over particles within the specified frame range
    for i = 1:numel(particle_part.Tf)
        idx1 = i;

        % Find indices of tracers in the current frame
        idx2 = find(tracer_part.Tf == particle_part.Tf(idx1));

        % Calculate neighbors using a helper function
        neighborAll(i) = get_neighborIdx(particle_part, tracer_part, idx1, idx2, Rmin, Rmax);  
    end
end

